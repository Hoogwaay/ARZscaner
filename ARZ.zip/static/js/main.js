// 🌌 Arizona Scanner v3.0 — AWWwards GRAND PRIX Edition
// 🔥 Particles + Parallax + Твоя логика (100% рабочий)

let scannerLoading = false;
let arbitrageLoading = false;

// 🔥 AWWwards PARTICLE SYSTEM (синий градиент как на Awwwards)
function initParticles() {
    const canvas = document.getElementById('bg-canvas');
    const ctx = canvas.getContext('2d');

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const particles = [];
    const particleCount = 150; // Больше частиц для премиум вида

    class Particle {
        constructor() {
            this.x = Math.random() * canvas.width;
            this.y = Math.random() * canvas.height;
            this.size = Math.random() * 2.5 + 0.5;
            this.speedX = Math.random() * 0.4 - 0.2;
            this.speedY = Math.random() * 0.4 - 0.2;
            this.hue = Math.random() * 30 + 210; // Голубой спектр Awwwards
            this.opacity = Math.random() * 0.5 + 0.3;
        }

        update() {
            this.x += this.speedX;
            this.y += this.speedY;

            if (this.x < 0 || this.x > canvas.width) this.speedX *= -1;
            if (this.y < 0 || this.y > canvas.height) this.speedY *= -1;

            // Легкое мерцание
            this.opacity = 0.3 + Math.sin(Date.now() * 0.005 + this.x * 0.01) * 0.2;
        }

        draw() {
            ctx.save();
            ctx.globalAlpha = this.opacity;
            const gradient = ctx.createRadialGradient(this.x, this.y, 0, this.x, this.y, this.size * 2);
            gradient.addColorStop(0, `hsla(${this.hue}, 70%, 60%, 0.8)`);
            gradient.addColorStop(1, `hsla(${this.hue}, 70%, 60%, 0)`);
            ctx.fillStyle = gradient;
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size * 2, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
        }
    }

    for (let i = 0; i < particleCount; i++) {
        particles.push(new Particle());
    }

    function animate() {
        ctx.fillStyle = 'rgba(10, 10, 20, 0.1)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        particles.forEach(p => {
            p.update();
            p.draw();
        });
        requestAnimationFrame(animate);
    }

    animate();

    window.addEventListener('resize', () => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    });
}

// 🌀 MOUSE PARALLAX (как на Awwwards winners)
function initParallax() {
    document.addEventListener('mousemove', (e) => {
        const hero = document.querySelector('[data-parallax="hero"]');
        const x = (e.clientX / window.innerWidth - 0.5) * 25;
        const y = (e.clientY / window.innerHeight - 0.5) * 25;
        if (hero) {
            hero.style.transform = `translate(${x}px, ${y}px) rotateX(${-y * 0.1}deg) rotateY(${x * 0.1}deg)`;
        }

        // Легкий эффект на кнопки
        const buttons = document.querySelectorAll('.shimmer');
        buttons.forEach((btn, i) => {
            const btnX = (e.clientX / window.innerWidth - 0.5) * 5;
            const btnY = (e.clientY / window.innerHeight - 0.5) * 5;
            btn.style.transform = `translate(${btnX}px, ${btnY}px)`;
        });
    });
}

// 🔄 Переключение табов (твоя оригинальная)
function switchTab(tabName) {
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    document.getElementById(tabName).classList.add('active');
    if (tabName === 'scanner') loadScanner();
    else loadArbitrage();
}

// 📦 Модальное окно инвентаря (твоя оригинальная)
async function showInventoryModal() {
    const modal = document.getElementById('inventoryModal');
    const content = document.getElementById('inventoryContent');

    content.innerHTML = '<div class="loading-state"><div class="loading-spinner"></div><p>⏳ Загрузка инвентаря...</p></div>';
    modal.style.display = 'flex';

    try {
        const response = await fetch('/api/inventory-summary');
        const data = await response.json();

        if (data.success && data.data.items.length > 0) {
            let html = `
                <div style="font-size:1.2em;margin-bottom:24px;text-align:center;">
                    <strong>${data.data.item_types} видов</strong> |
                    <strong>${data.data.total_items.toLocaleString()} шт</strong> |
                    <strong style="color:#8EE4AF;">${data.data.total_cost.toLocaleString()}$ SA$</strong>
                </div>
            `;

            data.data.items.forEach(item => {
                html += `
                    <div class="inventory-item">
                        <div>
                            <div style="font-weight:700;font-size:1.1em;">${item.name}</div>
                            <div style="color:#5CDB95;font-size:0.95em;">${item.qty.toLocaleString()} шт</div>
                        </div>
                        <div style="color:#8EE4AF;font-weight:700;font-size:1.3em;">
                            ${item.total_cost.toLocaleString()}$
                        </div>
                    </div>
                `;
            });

            html += `
                <div class="inventory-total">
                    📊 ИТОГО: ${data.data.total_items.toLocaleString()} шт<br>
                    <span style="font-size:1.5em;">${data.data.total_cost.toLocaleString()}$ SA$</span>
                </div>
            `;
            content.innerHTML = html;
        } else {
            content.innerHTML = '<div style="text-align:center;padding:120px;color:#907163;font-size:20px;">📭 Инвентарь пуст</div>';
        }
    } catch (e) {
        content.innerHTML = '<div style="text-align:center;padding:120px;color:#907163;font-size:20px;">❌ Ошибка загрузки</div>';
    }
}

function closeInventoryModal() {
    document.getElementById('inventoryModal').style.display = 'none';
}

// 🛒 Scanner функции (твои оригинальные)
async function loadScanner() {
    const response = await fetch('/api/scanner');
    const data = await response.json();
    updateScannerContent(data);
}

async function scanScanner() {
    if (scannerLoading) return;
    scannerLoading = true;
    const content = document.getElementById('scanner-content');
    content.innerHTML = '<div class="loading-state"><div class="loading-spinner"></div><p>⏳ Сканирую лавки...</p></div>';

    await fetch('/scan_scanner', {method: 'POST'});
    setTimeout(() => {
        loadScanner();
        scannerLoading = false;
    }, 2500);
}

async function toggleAutoScanner() {
    const response = await fetch('/toggle_auto_scanner', {method: 'POST'});
    const result = await response.json();
    const btn = document.getElementById('auto-scanner-btn');
    const status = document.getElementById('scanner-status');

    if (result.scanner_running) {
        btn.innerHTML = '<span class="btn-state">✅ ВКЛ</span><span class="btn-label">Автоскан</span>';
        btn.classList.add('active');
        status.innerHTML = '<div class="status-icon">✅</div><div class="status-text">АВТОСКАН: каждые 30 сек</div>';
        status.style.borderLeft = '5px solid #8EE4AF';
    } else {
        btn.innerHTML = '<span class="btn-state">🚫 ВЫКЛ</span><span class="btn-label">Автоскан</span>';
        btn.classList.remove('active');
        status.innerHTML = '<div class="status-icon">⏳</div><div class="status-text">Автоскан выключен</div>';
    }
}

// 🔄 Arbitrage функции (твои оригинальные)
async function loadArbitrage() {
    const response = await fetch('/api/arbitrage');
    const data = await response.json();
    updateArbitrageContent(data.data);
}

async function scanArbitrage() {
    if (arbitrageLoading) return;
    arbitrageLoading = true;
    const btn = document.getElementById('arbitrage-scan-btn');
    const status = document.getElementById('arbitrage-status');

    btn.disabled = true;
    btn.innerHTML = '<span class="btn-icon">⏳</span>Сканирую...';
    status.innerHTML = '<div class="status-icon">⏳</div><div class="status-text">Ручной скан...</div>';

    await fetch('/scan_arbitrage', {method: 'POST'});
    setTimeout(() => {
        loadArbitrage();
        btn.disabled = false;
        btn.innerHTML = '<span class="btn-icon">🌌</span>Ручной скан';
        arbitrageLoading = false;
    }, 2500);
}

async function toggleAutoArbitrage() {
    const response = await fetch('/toggle_auto_arbitrage', {method: 'POST'});
    const result = await response.json();
    const btn = document.getElementById('auto-arbitrage-btn');

    if (result.arbitrage_running) {
        btn.innerHTML = '<span class="btn-state">✅ ВКЛ</span><span class="btn-label">Автоарби</span>';
        btn.classList.add('active');
    } else {
        btn.innerHTML = '<span class="btn-state">🚫 ВЫКЛ</span><span class="btn-label">Автоарби</span>';
        btn.classList.remove('active');
    }
}

// 📊 updateScannerContent (твоя оригинальная — полная)
function updateScannerContent(data) {
    const content = document.getElementById('scanner-content');
    if (!data.success || !data.data) {
        content.innerHTML = '<div class="loading-state"><div class="loading-spinner"></div><p>📭 Нет данных в inventory.json. Запусти ручной скан!</p></div>';
        return;
    }

    const [lavki_sorted, total_stats] = data.data;
    let html = `
        <div class="stats">
            <h3>📊 ИТОГО: ${total_stats.lavka_count} лавок |
            ${total_stats.total_items} позиций |
            ${total_stats.item_groups} групп |
            <span class="profit-${total_stats.total_profit >= 0 ? 'positive' : 'negative'}">
            ${total_stats.total_profit.toLocaleString()}$ SA$
            </span></h3>
        </div>
    `;

    lavki_sorted.forEach(([lavka_uid, item_groups]) => {
        const lavka_total_profit = Object.values(item_groups).flat().reduce((sum, pos) => sum + pos.profit, 0);

        html += `
            <div class="lavka">
                <h3 style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
                    <span>🏪 Лавка #${lavka_uid} (${Object.keys(item_groups).length} предметов)</span>
                    <span class="profit-${lavka_total_profit >= 0 ? 'positive' : 'negative'}">
                        ${lavka_total_profit.toLocaleString()}$
                    </span>
                    <button class="copy-btn" onclick="copyToClipboard('/findilavka ${lavka_uid}')" title="Копировать команду">📋</button>
                </h3>
        `;

        Object.entries(item_groups).forEach(([item_name, positions]) => {
            const item_total_profit = positions.reduce((sum, pos) => sum + pos.profit, 0);
            const best_price = Math.max(...positions.map(p => p.lavka_price));

            html += `
                <div style="padding:20px;background:rgba(92,219,149,0.1);border-radius:12px;margin-bottom:15px;cursor:pointer;border:1px solid rgba(142,228,175,0.3);transition:all 0.3s;" onclick="this.querySelector('.details').style.display = this.querySelector('.details').style.display === 'block' ? 'none' : 'block'">
                    <div style="display:flex;justify-content:space-between;align-items:center;">
                        <div>
                            <b style="font-size:1.1em;">${item_name}</b>
                            <span style="color:#5CDB95;"> ×${positions.reduce((sum, p) => sum + p.quantity, 0)}</span>
                        </div>
                        <div style="text-align:right;">
                            <div style="color:#8EE4AF;">${best_price.toLocaleString()} VC$</div>
                            <span class="profit-${item_total_profit >= 0 ? 'positive' : 'negative'}" style="font-size:1.2em;font-weight:700;">
                                💎 ${item_total_profit.toLocaleString()}$
                            </span>
                            <span style="font-size:0.9em;color:#907163;"> (${positions.length} позиций)</span>
                        </div>
                    </div>
                    <div class="details" style="display:none;margin-top:15px;padding:15px;background:rgba(0,0,0,0.5);border-radius:10px;">
            `;

            positions.forEach(position => {
                html += `
                    <div style="padding:12px;margin-bottom:8px;background:${position.profit >= 0 ? 'rgba(142,228,175,0.2)' : 'rgba(144,113,99,0.2)'};border-radius:10px;border-left:4px solid ${position.profit >= 0 ? '#8EE4AF' : '#907163'};">
                        <div><b>${position.name}</b> × ${position.quantity}</div>
                        <div style="color:#5CDB95;font-size:0.9em;">
                            Куплено: ${position.buy_price.toLocaleString()}$ (${position.buy_price_per_unit.toLocaleString()}$/шт)
                        </div>
                        <div style="color:#8EE4AF;font-size:0.9em;">
                            Лавка: ${position.lavka_price.toLocaleString()}$ VC$ (${position.lavka_count} шт)
                        </div>
                        <div class="profit-${position.profit >= 0 ? 'positive' : 'negative'}" style="font-weight:700;font-size:1.1em;">
                            💎 ${position.profit.toLocaleString()}$ профит
                        </div>
                    </div>
                `;
            });

            html += `</div></div>`;
        });

        html += `</div>`;
    });

    content.innerHTML = html;
}

// ✅ updateArbitrageContent (твоя полная оригинальная)
function updateArbitrageContent(data) {
    document.getElementById('arbitrage-status').innerHTML = `<b>${data.status}</b> | ${data.last_update}`;

    const deals = data.cross5 || [];
    const content = document.getElementById('arbitrage-content');

    if (!deals.length) {
        content.innerHTML = '<div class="loading-state"><div class="loading-spinner"></div><p>📭 Нет арбитражных сделок 5→0</p></div>';
        return;
    }

    let html = `
        <div style="background:rgba(142,228,175,0.15);padding:25px;border-radius:15px;margin-bottom:25px;border-left:5px solid #8EE4AF;">
            <h3 style="color:#379683;text-align:center;font-size:1.3em;">🔄 АРБИТРАЖ 5→0 (${deals.length} сделок)</h3>
        </div>
    `;

    const buyGroups = {};
    deals.forEach(deal => {
        if (!buyGroups[deal.lavka_buy]) buyGroups[deal.lavka_buy] = [];
        buyGroups[deal.lavka_buy].push(deal);
    });

    const sortedLavkas = Object.keys(buyGroups)
        .map(lavka => ({
            id: lavka,
            profit: buyGroups[lavka].reduce((sum, deal) => sum + deal.total_profit, 0)
        }))
        .sort((a, b) => b.profit - a.profit)
        .map(item => item.id);

    sortedLavkas.forEach(buyLavka => {
        const groupDeals = buyGroups[buyLavka];
        const groupProfit = groupDeals.reduce((sum, deal) => sum + deal.total_profit, 0);

        html += `
            <div class="lavka">
                <h3 style="background:linear-gradient(135deg,#907163,#8EE4AF);color:#000000;padding:15px 20px;border-radius:12px;margin-bottom:15px;display:flex;justify-content:space-between;align-items:center;">
                    <span>🛒 Лавка #${buyLavka} (${groupDeals.length} сделок)</span>
                    <span style="font-size:1.3em;font-weight:700;">+${groupProfit.toLocaleString()}$</span>
                </h3>
                <table class="deals-table">
                    <thead>
                        <tr>
                            <th>Продать 0</th><th>Предмет</th><th>VC$ Buy</th><th>VC$ Sell</th>
                            <th>Профит/шт</th><th>Общий</th><th>Кол-во</th><th></th>
                        </tr>
                    </thead>
                    <tbody>
        `;

        groupDeals.sort((a, b) => b.total_profit - a.total_profit);
        groupDeals.slice(0, 20).forEach(deal => {
            html += `
                <tr>
                    <td style="color:#8EE4AF;font-weight:700;">#${deal.lavka_sell}</td>
                    <td style="font-size:0.9em;">${deal.item.slice(0, 25)}${deal.item.length > 25 ? '...' : ''}</td>
                    <td>${deal.price_buy.toLocaleString()}</td>
                    <td>${deal.price_sell.toLocaleString()}</td>
                    <td style="color:#8EE4AF;font-weight:700;">+${deal.profit.toLocaleString()}</td>
                    <td style="color:#8EE4AF;font-weight:700;">+${deal.total_profit.toLocaleString()}$</td>
                    <td>${deal.count_buy}</td>
                    <td><button class="copy-btn" onclick="copyToClipboard('/findilavka ${deal.lavka_sell}')">📋 ПРОДАТЬ</button></td>
                </tr>
            `;
        });

        html += `</tbody></table>`;
        if (groupDeals.length > 20) {
            html += `<div style="text-align:center;color:#907163;padding:15px;">... +${groupDeals.length - 20} сделок</div>`;
        }
        html += `</div>`;
    });

    content.innerHTML = html;
}

// 🛠️ Утилиты (твоя оригинальная)
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        const btn = event.target;
        const original = btn.innerHTML;
        btn.innerHTML = '✅';
        btn.style.background = '#8EE4AF';
        setTimeout(() => {
            btn.innerHTML = original;
            btn.style.background = '';
        }, 1500);
    });
}

// 👂 ИНИЦИАЛИЗАЦИЯ AWWwards + твоя логика
document.addEventListener('DOMContentLoaded', function() {
    // 🔥 AWWwards фичи
    initParticles();
    initParallax();

    // Твоя оригинальная инициализация
    window.onclick = function(event) {
        const modal = document.getElementById('inventoryModal');
        if (event.target == modal) closeInventoryModal();
    };

    // Автообновление статусов каждые 5 сек
    setInterval(async () => {
        try {
            const response = await fetch('/api/auto_status');
            const status = await response.json();

            const scannerBtn = document.getElementById('auto-scanner-btn');
            if (status.scanner_running) {
                scannerBtn.innerHTML = '<span class="btn-state">✅ ВКЛ</span><span class="btn-label">Автоскан</span>';
                scannerBtn.classList.add('active');
            }

            const arbitrageBtn = document.getElementById('auto-arbitrage-btn');
            if (status.arbitrage_running) {
                arbitrageBtn.innerHTML = '<span class="btn-state">✅ ВКЛ</span><span class="btn-label">Автоарби</span>';
                arbitrageBtn.classList.add('active');
            }
        } catch(e) {}
    }, 5000);

    // Запуск
    loadScanner();
    toggleAutoScanner();
    toggleAutoArbitrage();

    // Обработчики кнопок
    document.getElementById('auto-scanner-btn').onclick = toggleAutoScanner;
    document.getElementById('auto-arbitrage-btn').onclick = toggleAutoArbitrage;

    // Автообновление сканера каждые 30 сек
    setInterval(() => {
        if (document.getElementById('scanner').classList.contains('active')) {
            loadScanner();
        }
    }, 30000);
});