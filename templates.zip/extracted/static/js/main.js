// Arizona Scanner v3.0 — Professional Edition

let scannerLoading = false;
let arbitrageLoading = false;

// ─── Arbitrage Filters ─────────────────────────────────────
let arbFilters = { minProfit: 0, minLavkas: 0, excludedItems: [] };
let lastArbitrageData = null;

function loadArbFilters() {
    try {
        const saved = localStorage.getItem('arbFilters');
        if (saved) arbFilters = JSON.parse(saved);
    } catch(e) {}
    const profitInp = document.getElementById('filter-min-profit');
    if (profitInp) profitInp.value = arbFilters.minProfit > 0 ? arbFilters.minProfit : '';
    const lavkasInp = document.getElementById('filter-min-lavkas');
    if (lavkasInp) lavkasInp.value = arbFilters.minLavkas > 0 ? arbFilters.minLavkas : '';
    renderExcludedTags();
    updateFilterBadge();
}

function saveArbFilters() {
    localStorage.setItem('arbFilters', JSON.stringify(arbFilters));
    updateFilterBadge();
}

function onFilterChange() {
    arbFilters.minProfit = parseInt(document.getElementById('filter-min-profit').value) || 0;
    arbFilters.minLavkas = parseInt(document.getElementById('filter-min-lavkas').value) || 0;
    saveArbFilters();
    if (lastArbitrageData) updateArbitrageContent(lastArbitrageData);
}

function toggleFilterPanel() {
    const panel = document.getElementById('arb-filter-panel');
    const btn = document.getElementById('arb-filter-btn');
    panel.classList.toggle('open');
    btn.classList.toggle('active', panel.classList.contains('open'));
}

function addExcludedItem() {
    const input = document.getElementById('filter-exclude-input');
    const val = input.value.trim();
    if (!val) return;
    if (!arbFilters.excludedItems.some(i => i.toLowerCase() === val.toLowerCase())) {
        arbFilters.excludedItems.push(val);
        saveArbFilters();
        renderExcludedTags();
        if (lastArbitrageData) updateArbitrageContent(lastArbitrageData);
    }
    input.value = '';
    input.focus();
}

function removeExcludedItem(index) {
    arbFilters.excludedItems.splice(index, 1);
    saveArbFilters();
    renderExcludedTags();
    if (lastArbitrageData) updateArbitrageContent(lastArbitrageData);
}

function renderExcludedTags() {
    const container = document.getElementById('excluded-tags');
    if (!container) return;
    if (!arbFilters.excludedItems.length) {
        container.innerHTML = '';
        return;
    }
    container.innerHTML = arbFilters.excludedItems.map((item, i) =>
        `<span class="exclude-tag">${item}<button class="tag-remove" onclick="removeExcludedItem(${i})">×</button></span>`
    ).join('');
}

function updateFilterBadge() {
    const badge = document.getElementById('filter-badge');
    if (!badge) return;
    const count = (arbFilters.minProfit > 0 ? 1 : 0) + (arbFilters.minLavkas > 0 ? 1 : 0) + arbFilters.excludedItems.length;
    if (count > 0) {
        badge.textContent = count;
        badge.style.display = 'inline-flex';
    } else {
        badge.style.display = 'none';
    }
}

function applyArbFilters(deals) {
    let filtered = deals;

    // Count lavkas per item
    const itemLavkaCounts = {};
    deals.forEach(d => {
        if (!itemLavkaCounts[d.item]) itemLavkaCounts[d.item] = new Set();
        itemLavkaCounts[d.item].add(d.lavka_sell);
    });

    // Apply filters
    if (arbFilters.minProfit > 0) {
        filtered = filtered.filter(d => d.total_profit >= arbFilters.minProfit);
    }
    if (arbFilters.minLavkas > 0) {
        filtered = filtered.filter(d => itemLavkaCounts[d.item].size >= arbFilters.minLavkas);
    }
    if (arbFilters.excludedItems.length > 0) {
        filtered = filtered.filter(d =>
            !arbFilters.excludedItems.some(ex =>
                d.item.toLowerCase().includes(ex.toLowerCase())
            )
        );
    }
    return filtered;
}

// ─── Background canvas (subtle dot grid) ───────────────────
function initCanvas() {
    const canvas = document.getElementById('bg-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    function resize() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    resize();
    window.addEventListener('resize', resize);

    const dots = [];
    const COUNT = 60;
    const colors = ['124,106,255', '34,211,238', '16,185,129'];
    for (let i = 0; i < COUNT; i++) {
        dots.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            r: Math.random() * 1.5 + 0.4,
            vx: (Math.random() - 0.5) * 0.12,
            vy: (Math.random() - 0.5) * 0.12,
            o: Math.random() * 0.35 + 0.1,
            c: colors[Math.floor(Math.random() * colors.length)]
        });
    }

    function draw() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        dots.forEach(d => {
            d.x += d.vx;
            d.y += d.vy;
            if (d.x < 0 || d.x > canvas.width) d.vx *= -1;
            if (d.y < 0 || d.y > canvas.height) d.vy *= -1;

            ctx.beginPath();
            ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(${d.c},${d.o})`;
            ctx.fill();
        });

        // Draw lines between close dots
        for (let i = 0; i < dots.length; i++) {
            for (let j = i + 1; j < dots.length; j++) {
                const dx = dots[i].x - dots[j].x;
                const dy = dots[i].y - dots[j].y;
                const dist = Math.sqrt(dx*dx + dy*dy);
                if (dist < 110) {
                    ctx.beginPath();
                    ctx.moveTo(dots[i].x, dots[i].y);
                    ctx.lineTo(dots[j].x, dots[j].y);
                    ctx.strokeStyle = `rgba(124,106,255,${0.07 * (1 - dist/110)})`;
                    ctx.lineWidth = 0.5;
                    ctx.stroke();
                }
            }
        }
        requestAnimationFrame(draw);
    }
    draw();
}

// ─── Tab switching ──────────────────────────────────────────
function switchTab(tabName) {
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    document.querySelectorAll('.bnav-item').forEach(n => n.classList.remove('active'));

    document.getElementById(tabName).classList.add('active');
    const sideNav = document.getElementById('nav-' + tabName);
    if (sideNav) sideNav.classList.add('active');
    const botNav = document.getElementById('bnav-' + tabName);
    if (botNav) botNav.classList.add('active');

    const titles = {
        scanner:   ['Продажа через лавки', 'inventory.json · сервер 0'],
        arbitrage: ['Арбитраж 5→0',        'Кросс-серверные сделки 5→0']
    };
    document.getElementById('page-title').textContent = titles[tabName][0];
    document.getElementById('page-subtitle').textContent = titles[tabName][1];

    if (tabName === 'scanner') loadScanner();
    else loadArbitrage();
}

// ─── Inventory Modal ────────────────────────────────────────
async function showInventoryModal() {
    const modal = document.getElementById('inventoryModal');
    const content = document.getElementById('inventoryContent');
    content.innerHTML = '<div class="empty-state"><div class="spinner"></div><p>Загрузка инвентаря...</p></div>';
    modal.classList.add('open');

    try {
        const res = await fetch('/api/inventory-summary');
        const data = await res.json();

        if (data.success && data.data.items.length > 0) {
            const d = data.data;
            let html = `
                <div class="inv-summary">
                    <div class="inv-sum-item">
                        <span class="inv-sum-label">Видов</span>
                        <span class="inv-sum-value">${d.item_types}</span>
                    </div>
                    <div class="inv-sum-item">
                        <span class="inv-sum-label">Штук</span>
                        <span class="inv-sum-value">${d.total_items.toLocaleString()}</span>
                    </div>
                    <div class="inv-sum-item">
                        <span class="inv-sum-label">Стоимость</span>
                        <span class="inv-sum-value gold">${d.total_cost.toLocaleString()}</span>
                    </div>
                </div>
            `;
            d.items.forEach(item => {
                html += `
                    <div class="inv-item">
                        <div>
                            <div class="inv-name">${item.name}</div>
                            <div class="inv-qty">${item.qty.toLocaleString()} шт</div>
                        </div>
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <span class="inv-cost">${item.total_cost.toLocaleString()} SA$</span>
                            <button class="btn-delete-item" onclick="deleteItem('${item.name.replace(/'/g, "\\'")}')">
                                <svg width="14" height="14" viewBox="0 0 20 20" fill="none">
                                    <path d="M3 5h14M8 5V3h4v2M8 9v6M12 9v6M5 5h10l-1 13H6L5 5Z" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                `;
            });
            content.innerHTML = html;
        } else {
            content.innerHTML = '<div class="empty-state"><p>Инвентарь пуст</p></div>';
        }
        updateHeaderStats();
    } catch(e) {
        content.innerHTML = '<div class="empty-state"><p>Ошибка загрузки</p></div>';
    }
}

function closeInventoryModal() {
    document.getElementById('inventoryModal').classList.remove('open');
}

// ─── Scanner ────────────────────────────────────────────────
async function loadScanner() {
    try {
        const res = await fetch('/api/scanner');
        const data = await res.json();
        updateScannerContent(data);
    } catch(e) {}
}

async function scanScanner() {
    if (scannerLoading) return;
    scannerLoading = true;
    document.getElementById('scanner-content').innerHTML =
        '<div class="empty-state"><div class="spinner"></div><p>Сканирую лавки...</p></div>';
    await fetch('/scan_scanner', {method: 'POST'});
    setTimeout(() => { loadScanner(); scannerLoading = false; }, 2500);
}

async function toggleAutoScanner() {
    const res = await fetch('/toggle_auto_scanner', {method: 'POST'});
    const result = await res.json();
    const btn = document.getElementById('auto-scanner-btn');
    const dot = document.getElementById('dot-scanner');
    if (result.scanner_running) {
        btn.classList.add('active');
        btn.querySelector('.toggle-label').textContent = 'Автоскан: ВКЛ';
        dot.classList.add('on');
        setStatus('scanner-status', 'ok', 'Автоскан активен — обновление каждые 30 сек');
    } else {
        btn.classList.remove('active');
        btn.querySelector('.toggle-label').textContent = 'Автоскан';
        dot.classList.remove('on');
        setStatus('scanner-status', '', 'Автоскан выключен');
    }
}

// ─── Arbitrage ──────────────────────────────────────────────
async function loadArbitrage() {
    try {
        const res = await fetch('/api/arbitrage');
        const data = await res.json();
        updateArbitrageContent(data.data);
    } catch(e) {}
}

async function scanArbitrage() {
    if (arbitrageLoading) return;
    arbitrageLoading = true;
    const btn = document.getElementById('arbitrage-scan-btn');
    btn.disabled = true;
    btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="7" stroke="currentColor" stroke-width="1.5"/></svg> Сканирую...';
    setStatus('arbitrage-status', '', 'Ручной скан...');

    await fetch('/scan_arbitrage', {method: 'POST'});
    setTimeout(() => {
        loadArbitrage();
        btn.disabled = false;
        btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 20 20" fill="none"><path d="M3 10h14M13 6l4 4-4 4M7 6L3 10l4 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg> Ручной скан';
        arbitrageLoading = false;
    }, 2500);
}

async function toggleAutoArbitrage() {
    const res = await fetch('/toggle_auto_arbitrage', {method: 'POST'});
    const result = await res.json();
    const btn = document.getElementById('auto-arbitrage-btn');
    const dot = document.getElementById('dot-arbitrage');
    if (result.arbitrage_running) {
        btn.classList.add('active');
        btn.querySelector('.toggle-label').textContent = 'Автоарби: ВКЛ';
        dot.classList.add('on');
    } else {
        btn.classList.remove('active');
        btn.querySelector('.toggle-label').textContent = 'Автоарби';
        dot.classList.remove('on');
    }
}

// ─── Status bar helper ──────────────────────────────────────
function setStatus(id, type, text) {
    const bar = document.getElementById(id);
    if (!bar) return;
    const ind = bar.querySelector('.status-indicator');
    if (ind) { ind.className = 'status-indicator' + (type ? ' ' + type : ''); }
    const span = bar.querySelector('span');
    if (span) span.textContent = text;
}

// ─── Render Scanner ─────────────────────────────────────────
function updateScannerContent(data) {
    const content = document.getElementById('scanner-content');
    if (!data.success || !data.data) {
        setStatus('scanner-status', '', 'Нет данных — запустите ручной скан');
        content.innerHTML = '<div class="empty-state"><p>Нет данных в inventory.json</p></div>';
        return;
    }

    const [lavki_sorted, total_stats] = data.data;
    setStatus('scanner-status', 'ok', `Найдено ${total_stats.lavka_count} лавок · ${total_stats.total_items} позиций · Профит: ${total_stats.total_profit.toLocaleString()} SA$`);

    let html = `
        <div class="stats-card">
            <div class="stat-item">
                <span class="stat-label">Лавок</span>
                <span class="stat-value">${total_stats.lavka_count}</span>
            </div>
            <div class="stat-item">
                <span class="stat-label">Позиций</span>
                <span class="stat-value">${total_stats.total_items}</span>
            </div>
            <div class="stat-item">
                <span class="stat-label">Групп</span>
                <span class="stat-value">${total_stats.item_groups}</span>
            </div>
            <div class="stat-item">
                <span class="stat-label">Общий профит</span>
                <span class="stat-value ${total_stats.total_profit >= 0 ? 'green' : ''}">${total_stats.total_profit.toLocaleString()} SA$</span>
            </div>
        </div>
    `;

    lavki_sorted.forEach(([lavka_uid, item_groups]) => {
        const lavka_total_profit = Object.values(item_groups).flat().reduce((s, p) => s + p.profit, 0);
        const itemCount = Object.keys(item_groups).length;

        html += `
            <div class="lavka-card">
                <div class="lavka-head">
                    <div class="lavka-icon">🏪</div>
                    <span class="lavka-id">Лавка #${lavka_uid}</span>
                    <span class="lavka-items-count">${itemCount} предм.</span>
                    <span class="lavka-profit ${lavka_total_profit >= 0 ? 'pos' : 'neg'}">${lavka_total_profit >= 0 ? '+' : ''}${lavka_total_profit.toLocaleString()} SA$</span>
                    <button class="copy-cmd-btn" onclick="copyToClipboard('/findilavka ${lavka_uid}')">
                        <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><rect x="5" y="5" width="8" height="8" rx="1" stroke="currentColor" stroke-width="1.2"/><path d="M3 11V3h8" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                        /findilavka
                    </button>
                </div>
                <div class="lavka-body">
        `;

        // Sort items by profit descending
        const sortedItems = Object.entries(item_groups).sort((a, b) => {
            const profitA = a[1].reduce((s, p) => s + p.profit, 0);
            const profitB = b[1].reduce((s, p) => s + p.profit, 0);
            return profitB - profitA;
        });
        
        sortedItems.forEach(([item_name, positions]) => {
            const item_total_profit = positions.reduce((s, p) => s + p.profit, 0);
            const best_price = Math.max(...positions.map(p => p.lavka_price));
            const total_qty = positions.reduce((s, p) => s + p.quantity, 0);
            const rowId = 'row-' + Math.random().toString(36).slice(2);

            html += `
                <div class="item-row" id="${rowId}" onclick="toggleItemRow('${rowId}')">
                    <div class="item-row-head">
                        <div>
                            <span class="item-name">${item_name}</span>
                            <span class="item-qty"> ×${total_qty}</span>
                        </div>
                        <div class="item-meta">
                            <span class="item-price">${best_price.toLocaleString()} VC$</span>
                            <span class="item-profit ${item_total_profit >= 0 ? 'pos' : 'neg'}">${item_total_profit >= 0 ? '+' : ''}${item_total_profit.toLocaleString()} SA$</span>
                            <span class="item-chevron">▼</span>
                        </div>
                    </div>
                    <div class="item-details">
            `;

            positions.forEach(pos => {
                html += `
                    <div class="detail-line ${pos.profit >= 0 ? 'profit-ok' : 'profit-bad'}">
                        <div class="detail-line-left">
                            <span class="detail-name">${pos.name} ×${pos.quantity}</span>
                            <span class="detail-buy">Куплено: ${pos.buy_price.toLocaleString()} SA$ · ${pos.buy_price_per_unit.toLocaleString()} SA$/шт</span>
                        </div>
                        <div class="detail-line-right">
                            <span class="detail-lavka">${pos.lavka_price.toLocaleString()} VC$ · ${pos.lavka_count} шт</span>
                            <span class="detail-profit ${pos.profit >= 0 ? 'pos' : 'neg'}">${pos.profit >= 0 ? '+' : ''}${pos.profit.toLocaleString()} SA$</span>
                        </div>
                    </div>
                `;
            });

            html += `</div></div>`;
        });

        html += `</div></div>`;
    });

    content.innerHTML = html;
}

function toggleItemRow(id) {
    document.getElementById(id).classList.toggle('open');
}

// ─── Render Arbitrage ───────────────────────────────────────
function updateArbitrageContent(data) {
    lastArbitrageData = data;
    const allDeals = data.cross5 || [];
    const deals = applyArbFilters(allDeals);
    const hiddenCount = allDeals.length - deals.length;

    const statusText = data.status + (data.last_update ? ' · ' + data.last_update : '');
    setStatus('arbitrage-status', deals.length ? 'ok' : '', statusText);

    const content = document.getElementById('arbitrage-content');

    if (!deals.length) {
        const msg = hiddenCount > 0
            ? `Все ${allDeals.length} сделок скрыты фильтрами`
            : 'Нет арбитражных сделок 5→0';
        content.innerHTML = `<div class="empty-state"><p>${msg}</p></div>`;
        return;
    }

    // Calculate total cost and profit from filtered deals
    const totalCost = deals.reduce((s, d) => s + (d.price_buy * d.count_buy), 0);
    const totalProfit = deals.reduce((s, d) => s + d.total_profit, 0);

    const buyGroups = {};
    deals.forEach(deal => {
        if (!buyGroups[deal.lavka_buy]) buyGroups[deal.lavka_buy] = [];
        buyGroups[deal.lavka_buy].push(deal);
    });

    const sortedLavkas = Object.keys(buyGroups)
        .map(id => ({ id, profit: buyGroups[id].reduce((s, d) => s + d.total_profit, 0) }))
        .sort((a, b) => b.profit - a.profit)
        .map(x => x.id);

    const hiddenNote = hiddenCount > 0 ? ` <span style="font-size:11px;color:var(--text-muted);font-weight:400;">(${hiddenCount} скрыто)</span>` : '';

    let html = `
        <div class="stats-card">
            <div class="stat-item">
                <span class="stat-label">Сумма товаров</span>
                <span class="stat-value">${totalCost.toLocaleString()} SA$</span>
            </div>
            <div class="stat-item">
                <span class="stat-label">Общий профит</span>
                <span class="stat-value green">${totalProfit.toLocaleString()} SA$</span>
            </div>
            <div class="stat-item">
                <span class="stat-label">Сделок</span>
                <span class="stat-value">${deals.length}${hiddenNote}</span>
            </div>
        </div>
        <div class="arb-section-header">
            Арбитраж 5→0 — ${deals.length} из ${allDeals.length} сделок · Купить на сервере 5, продать на сервере 0
        </div>
    `;

    sortedLavkas.forEach(buyLavka => {
        const groupDeals = [...buyGroups[buyLavka]].sort((a, b) => b.total_profit - a.total_profit);
        const groupProfit = groupDeals.reduce((s, d) => s + d.total_profit, 0);

        html += `
            <div class="arb-card">
                <div class="arb-head">
                    <div class="arb-icon">⇄</div>
                    <span class="arb-id">Лавка #${buyLavka} <span style="color:var(--text-muted);font-weight:400;font-size:12px;">серв. 5</span></span>
                    <span class="arb-count">${groupDeals.length} сделок</span>
                    <span class="arb-total">+${groupProfit.toLocaleString()} SA$</span>
                </div>
                <div class="table-wrap">
                    <table class="arb-table">
                        <thead>
                            <tr>
                                <th>Продать в лавку</th>
                                <th>Предмет</th>
                                <th>Цена покупки</th>
                                <th>Цена продажи</th>
                                <th>Профит/шт</th>
                                <th>Итого</th>
                                <th>Кол-во</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
        `;

        groupDeals.slice(0, 20).forEach(deal => {
            html += `
                <tr>
                    <td class="td-sell">#${deal.lavka_sell}</td>
                    <td class="td-item" title="${deal.item}">${deal.item.slice(0, 28)}${deal.item.length > 28 ? '…' : ''}</td>
                    <td class="td-num">${deal.price_buy.toLocaleString()}</td>
                    <td class="td-num">${deal.price_sell.toLocaleString()}</td>
                    <td class="td-profit">+${deal.profit.toLocaleString()}</td>
                    <td class="td-profit">+${deal.total_profit.toLocaleString()} SA$</td>
                    <td class="td-num">${deal.count_buy}</td>
                    <td class="td-action"><button class="btn-copy-small" onclick="copyToClipboard('/findilavka ${deal.lavka_sell}')">копировать</button></td>
                </tr>
            `;
        });

        html += `</tbody></table>`;
        if (groupDeals.length > 20) {
            html += `<div class="more-deals">+${groupDeals.length - 20} ещё сделок</div>`;
        }
        html += `</div></div>`;
    });

    content.innerHTML = html;
}

// ─── Copy utility ───────────────────────────────────────────
function copyToClipboard(text) {
    const btn = event.currentTarget;
    navigator.clipboard.writeText(text).then(() => {
        const orig = btn.textContent;
        btn.textContent = 'скопировано';
        btn.style.color = 'var(--green)';
        btn.style.borderColor = 'rgba(16,185,129,0.4)';
        setTimeout(() => {
            btn.textContent = orig;
            btn.style.color = '';
            btn.style.borderColor = '';
        }, 1500);
    });
}

// ─── Init ───────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
    initCanvas();

    // Close modal on backdrop click
    document.getElementById('inventoryModal').addEventListener('click', function(e) {
        if (e.target === this) closeInventoryModal();
    });

    // Poll auto-status every 5s
    async function pollStatus() {
        try {
            const res = await fetch('/api/auto_status');
            const status = await res.json();

            const scanBtn = document.getElementById('auto-scanner-btn');
            const scanDot = document.getElementById('dot-scanner');
            if (status.scanner_running) {
                scanBtn.classList.add('active');
                scanBtn.querySelector('.toggle-label').textContent = 'Автоскан: ВКЛ';
                scanDot.classList.add('on');
            }

            const arbBtn = document.getElementById('auto-arbitrage-btn');
            const arbDot = document.getElementById('dot-arbitrage');
            if (status.arbitrage_running) {
                arbBtn.classList.add('active');
                arbBtn.querySelector('.toggle-label').textContent = 'Автоарби: ВКЛ';
                arbDot.classList.add('on');
            }
        } catch(e) {}
    }

    setInterval(pollStatus, 5000);

    // Auto-reload scanner data every 30s
    setInterval(() => {
        if (document.getElementById('scanner').classList.contains('active')) loadScanner();
    }, 30000);

    // Auto-reload arbitrage data every 10s when tab is active
    setInterval(() => {
        const arbBtn = document.getElementById('auto-arbitrage-btn');
        if (arbBtn.classList.contains('active') && document.getElementById('arbitrage').classList.contains('active')) {
            loadArbitrage();
        }
    }, 10000);

    // Wire up toggle buttons
    document.getElementById('auto-scanner-btn').onclick = toggleAutoScanner;
    document.getElementById('auto-arbitrage-btn').onclick = toggleAutoArbitrage;

    // Load saved filters
    loadArbFilters();

    // Initial load
    loadScanner();
    toggleAutoScanner();
    toggleAutoArbitrage();
    
    // Add item search input listener
    const itemSearchInput = document.getElementById('itemSearchInput');
    if (itemSearchInput) {
        itemSearchInput.addEventListener('input', searchItems);
    }
});

// ─── Item Add Modal Functions ────────────────────────────────────────
let selectedItem = null;

function openAddItemModal() {
    document.getElementById('addItemModal').classList.add('open');
    document.getElementById('itemSearchInput').focus();
}

function closeAddItemModal() {
    document.getElementById('addItemModal').classList.remove('open');
    document.getElementById('itemSearchInput').value = '';
    document.getElementById('itemSearchResults').innerHTML = '<p style="color: var(--text-secondary); text-align: center; padding: 20px;">Начните печатать для поиска...</p>';
}

function closeItemDetailsModal() {
    document.getElementById('itemDetailsModal').classList.remove('open');
    document.getElementById('itemQtyInput').value = '';
    document.getElementById('itemPriceInput').value = '';
    selectedItem = null;
}

async function searchItems(e) {
    const query = e.target.value.trim();
    const resultsDiv = document.getElementById('itemSearchResults');
    
    if (query.length < 1) {
        resultsDiv.innerHTML = '<p style="color: var(--text-secondary); text-align: center; padding: 20px;">Начните печатать для поиска...</p>';
        return;
    }
    
    resultsDiv.innerHTML = '<div style="text-align: center; padding: 20px;"><div class="spinner"></div></div>';
    
    try {
        const res = await fetch(`/api/search-items?q=${encodeURIComponent(query)}`);
        const data = await res.json();
        
        if (data.success && data.items.length > 0) {
            let html = '';
            data.items.forEach(item => {
                html += `
                    <div style="padding: 12px; background: var(--bg-card); border: 1px solid var(--border); border-radius: var(--radius-sm); cursor: pointer; margin-bottom: 8px; transition: all 0.2s;" 
                         onmouseover="this.style.borderColor = 'var(--gold)'; this.style.background = 'var(--bg-hover)';" 
                         onmouseout="this.style.borderColor = 'var(--border)'; this.style.background = 'var(--bg-card)';"
                         onclick="selectItem('${item.name}')">
                        <div style="font-weight: 500; color: var(--text-primary);">${item.name}</div>
                        <div style="font-size: 12px; color: var(--text-secondary);">ID: ${item.id} | Type: ${item.type}</div>
                    </div>
                `;
            });
            resultsDiv.innerHTML = html;
        } else {
            resultsDiv.innerHTML = '<p style="color: var(--text-secondary); text-align: center; padding: 20px;">Предметы не найдены</p>';
        }
    } catch(err) {
        resultsDiv.innerHTML = '<p style="color: var(--red); text-align: center; padding: 20px;">Ошибка поиска</p>';
    }
}

function selectItem(itemName) {
    selectedItem = itemName;
    closeAddItemModal();
    
    document.getElementById('itemDetailsName').textContent = itemName;
    document.getElementById('itemQtyInput').value = '';
    document.getElementById('itemPriceInput').value = '';
    document.getElementById('itemDetailsModal').classList.add('open');
    document.getElementById('itemQtyInput').focus();
}

async function confirmAddItem() {
    const qty = parseInt(document.getElementById('itemQtyInput').value) || 0;
    const price = parseInt(document.getElementById('itemPriceInput').value) || 0;
    
    if (qty <= 0) {
        alert('Введите корректное количество');
        return;
    }
    
    try {
        const res = await fetch('/api/add-item', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                name: selectedItem,
                qty: qty,
                price_per_unit: price
            })
        });
        
        const data = await res.json();
        if (data.success) {
            closeItemDetailsModal();
            showInventoryModal();
            updateHeaderStats();
        } else {
            alert('Ошибка добавления: ' + data.error);
        }
    } catch(err) {
        alert('Ошибка сохранения');
    }
}

async function updateHeaderStats() {
    try {
        const res = await fetch('/api/scanner');
        const scanData = await res.json();
        
        let totalCost = 0;
        let totalProfit = 0;
        
        if (scanData.success && scanData.data && scanData.data[0]) {
            const lavki = scanData.data[0];
            lavki.forEach(([lavka_uid, items]) => {
                Object.values(items).flat().forEach(item => {
                    totalCost += item.buy_price || 0;
                    totalProfit += item.profit || 0;
                });
            });
        }
        
        document.getElementById('header-total-cost').textContent = totalCost.toLocaleString() + ' SA$';
        document.getElementById('header-total-profit').textContent = totalProfit.toLocaleString() + ' SA$';
    } catch(e) {
        // Silently fail
    }
}

async function deleteItem(itemName) {
    if (!confirm(`Вы уверены, что хотите удалить "${itemName}"?`)) {
        return;
    }
    
    try {
        const res = await fetch('/api/delete-item', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name: itemName })
        });
        
        const data = await res.json();
        if (data.success) {
            showInventoryModal();
            updateHeaderStats();
        } else {
            alert('Ошибка удаления: ' + data.error);
        }
    } catch(err) {
        alert('Ошибка сохранения');
    }
}
