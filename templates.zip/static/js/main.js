// Arizona Scanner v3.0 — Professional Edition

let scannerLoading = false;
let arbitrageLoading = false;

// ─── Background canvas (subtle dot grid) ───────────────────
function initCanvas() {
    const canvas = document.getElementById('bg-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    function resize() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    resize();
    window.addEventListener('resize', resize);

    const dots = [];
    const COUNT = 80;
    for (let i = 0; i < COUNT; i++) {
        dots.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            r: Math.random() * 1.2 + 0.3,
            vx: (Math.random() - 0.5) * 0.15,
            vy: (Math.random() - 0.5) * 0.15,
            o: Math.random() * 0.3 + 0.1
        });
    }

    function draw() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        dots.forEach(d => {
            d.x += d.vx;
            d.y += d.vy;
            if (d.x < 0 || d.x > canvas.width) d.vx *= -1;
            if (d.y < 0 || d.y > canvas.height) d.vy *= -1;

            ctx.beginPath();
            ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(201,168,76,${d.o})`;
            ctx.fill();
        });

        // Draw lines between close dots
        for (let i = 0; i < dots.length; i++) {
            for (let j = i + 1; j < dots.length; j++) {
                const dx = dots[i].x - dots[j].x;
                const dy = dots[i].y - dots[j].y;
                const dist = Math.sqrt(dx*dx + dy*dy);
                if (dist < 100) {
                    ctx.beginPath();
                    ctx.moveTo(dots[i].x, dots[i].y);
                    ctx.lineTo(dots[j].x, dots[j].y);
                    ctx.strokeStyle = `rgba(201,168,76,${0.06 * (1 - dist/100)})`;
                    ctx.lineWidth = 0.5;
                    ctx.stroke();
                }
            }
        }
        requestAnimationFrame(draw);
    }
    draw();
}

// ─── Tab switching ──────────────────────────────────────────
function switchTab(tabName) {
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    document.querySelectorAll('.bnav-item').forEach(n => n.classList.remove('active'));

    document.getElementById(tabName).classList.add('active');
    const sideNav = document.getElementById('nav-' + tabName);
    if (sideNav) sideNav.classList.add('active');
    const botNav = document.getElementById('bnav-' + tabName);
    if (botNav) botNav.classList.add('active');

    const titles = {
        scanner:   ['Продажа через лавки', 'inventory.json · сервер 0'],
        arbitrage: ['Арбитраж 5→0',        'Кросс-серверные сделки 5→0']
    };
    document.getElementById('page-title').textContent = titles[tabName][0];
    document.getElementById('page-subtitle').textContent = titles[tabName][1];

    if (tabName === 'scanner') loadScanner();
    else loadArbitrage();
}

// ─── Inventory Modal ────────────────────────────────────────
async function showInventoryModal() {
    const modal = document.getElementById('inventoryModal');
    const content = document.getElementById('inventoryContent');
    content.innerHTML = '<div class="empty-state"><div class="spinner"></div><p>Загрузка инвентаря...</p></div>';
    modal.classList.add('open');

    try {
        const res = await fetch('/api/inventory-summary');
        const data = await res.json();

        if (data.success && data.data.items.length > 0) {
            const d = data.data;
            let html = `
                <div class="inv-summary">
                    <div class="inv-sum-item">
                        <span class="inv-sum-label">Видов</span>
                        <span class="inv-sum-value">${d.item_types}</span>
                    </div>
                    <div class="inv-sum-item">
                        <span class="inv-sum-label">Штук</span>
                        <span class="inv-sum-value">${d.total_items.toLocaleString()}</span>
                    </div>
                    <div class="inv-sum-item">
                        <span class="inv-sum-label">Стоимость</span>
                        <span class="inv-sum-value gold">${d.total_cost.toLocaleString()}</span>
                    </div>
                </div>
            `;
            d.items.forEach(item => {
                html += `
                    <div class="inv-item">
                        <div>
                            <div class="inv-name">${item.name}</div>
                            <div class="inv-qty">${item.qty.toLocaleString()} шт</div>
                        </div>
                        <span class="inv-cost">${item.total_cost.toLocaleString()} SA$</span>
                    </div>
                `;
            });
            content.innerHTML = html;
        } else {
            content.innerHTML = '<div class="empty-state"><p>Инвентарь пуст</p></div>';
        }
    } catch(e) {
        content.innerHTML = '<div class="empty-state"><p>Ошибка загрузки</p></div>';
    }
}

function closeInventoryModal() {
    document.getElementById('inventoryModal').classList.remove('open');
}

// ─── Scanner ────────────────────────────────────────────────
async function loadScanner() {
    try {
        const res = await fetch('/api/scanner');
        const data = await res.json();
        updateScannerContent(data);
    } catch(e) {}
}

async function scanScanner() {
    if (scannerLoading) return;
    scannerLoading = true;
    document.getElementById('scanner-content').innerHTML =
        '<div class="empty-state"><div class="spinner"></div><p>Сканирую лавки...</p></div>';
    await fetch('/scan_scanner', {method: 'POST'});
    setTimeout(() => { loadScanner(); scannerLoading = false; }, 2500);
}

async function toggleAutoScanner() {
    const res = await fetch('/toggle_auto_scanner', {method: 'POST'});
    const result = await res.json();
    const btn = document.getElementById('auto-scanner-btn');
    const dot = document.getElementById('dot-scanner');
    if (result.scanner_running) {
        btn.classList.add('active');
        btn.querySelector('.toggle-label').textContent = 'Автоскан: ВКЛ';
        dot.classList.add('on');
        setStatus('scanner-status', 'ok', 'Автоскан активен — обновление каждые 30 сек');
    } else {
        btn.classList.remove('active');
        btn.querySelector('.toggle-label').textContent = 'Автоскан';
        dot.classList.remove('on');
        setStatus('scanner-status', '', 'Автоскан выключен');
    }
}

// ─── Arbitrage ──────────────────────────────────────────────
async function loadArbitrage() {
    try {
        const res = await fetch('/api/arbitrage');
        const data = await res.json();
        updateArbitrageContent(data.data);
    } catch(e) {}
}

async function scanArbitrage() {
    if (arbitrageLoading) return;
    arbitrageLoading = true;
    const btn = document.getElementById('arbitrage-scan-btn');
    btn.disabled = true;
    btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="7" stroke="currentColor" stroke-width="1.5"/></svg> Сканирую...';
    setStatus('arbitrage-status', '', 'Ручной скан...');

    await fetch('/scan_arbitrage', {method: 'POST'});
    setTimeout(() => {
        loadArbitrage();
        btn.disabled = false;
        btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 20 20" fill="none"><path d="M3 10h14M13 6l4 4-4 4M7 6L3 10l4 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg> Ручной скан';
        arbitrageLoading = false;
    }, 2500);
}

async function toggleAutoArbitrage() {
    const res = await fetch('/toggle_auto_arbitrage', {method: 'POST'});
    const result = await res.json();
    const btn = document.getElementById('auto-arbitrage-btn');
    const dot = document.getElementById('dot-arbitrage');
    if (result.arbitrage_running) {
        btn.classList.add('active');
        btn.querySelector('.toggle-label').textContent = 'Автоарби: ВКЛ';
        dot.classList.add('on');
    } else {
        btn.classList.remove('active');
        btn.querySelector('.toggle-label').textContent = 'Автоарби';
        dot.classList.remove('on');
    }
}

// ─── Status bar helper ──────────────────────────────────────
function setStatus(id, type, text) {
    const bar = document.getElementById(id);
    if (!bar) return;
    const ind = bar.querySelector('.status-indicator');
    if (ind) { ind.className = 'status-indicator' + (type ? ' ' + type : ''); }
    const span = bar.querySelector('span');
    if (span) span.textContent = text;
}

// ─── Render Scanner ─────────────────────────────────────────
function updateScannerContent(data) {
    const content = document.getElementById('scanner-content');
    if (!data.success || !data.data) {
        setStatus('scanner-status', '', 'Нет данных — запустите ручной скан');
        content.innerHTML = '<div class="empty-state"><p>Нет данных в inventory.json</p></div>';
        return;
    }

    const [lavki_sorted, total_stats] = data.data;
    setStatus('scanner-status', 'ok', `Найдено ${total_stats.lavka_count} лавок · ${total_stats.total_items} позиций · Профит: ${total_stats.total_profit.toLocaleString()} SA$`);

    let html = `
        <div class="stats-card">
            <div class="stat-item">
                <span class="stat-label">Лавок</span>
                <span class="stat-value">${total_stats.lavka_count}</span>
            </div>
            <div class="stat-item">
                <span class="stat-label">Позиций</span>
                <span class="stat-value">${total_stats.total_items}</span>
            </div>
            <div class="stat-item">
                <span class="stat-label">Групп</span>
                <span class="stat-value">${total_stats.item_groups}</span>
            </div>
            <div class="stat-item">
                <span class="stat-label">Общий профит</span>
                <span class="stat-value ${total_stats.total_profit >= 0 ? 'green' : ''}">${total_stats.total_profit.toLocaleString()} SA$</span>
            </div>
        </div>
    `;

    lavki_sorted.forEach(([lavka_uid, item_groups]) => {
        const lavka_total_profit = Object.values(item_groups).flat().reduce((s, p) => s + p.profit, 0);
        const itemCount = Object.keys(item_groups).length;

        html += `
            <div class="lavka-card">
                <div class="lavka-head">
                    <div class="lavka-icon">🏪</div>
                    <span class="lavka-id">Лавка #${lavka_uid}</span>
                    <span class="lavka-items-count">${itemCount} предм.</span>
                    <span class="lavka-profit ${lavka_total_profit >= 0 ? 'pos' : 'neg'}">${lavka_total_profit >= 0 ? '+' : ''}${lavka_total_profit.toLocaleString()} SA$</span>
                    <button class="copy-cmd-btn" onclick="copyToClipboard('/findilavka ${lavka_uid}')">
                        <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><rect x="5" y="5" width="8" height="8" rx="1" stroke="currentColor" stroke-width="1.2"/><path d="M3 11V3h8" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                        /findilavka
                    </button>
                </div>
                <div class="lavka-body">
        `;

        Object.entries(item_groups).forEach(([item_name, positions]) => {
            const item_total_profit = positions.reduce((s, p) => s + p.profit, 0);
            const best_price = Math.max(...positions.map(p => p.lavka_price));
            const total_qty = positions.reduce((s, p) => s + p.quantity, 0);
            const rowId = 'row-' + Math.random().toString(36).slice(2);

            html += `
                <div class="item-row" id="${rowId}" onclick="toggleItemRow('${rowId}')">
                    <div class="item-row-head">
                        <div>
                            <span class="item-name">${item_name}</span>
                            <span class="item-qty"> ×${total_qty}</span>
                        </div>
                        <div class="item-meta">
                            <span class="item-price">${best_price.toLocaleString()} VC$</span>
                            <span class="item-profit ${item_total_profit >= 0 ? 'pos' : 'neg'}">${item_total_profit >= 0 ? '+' : ''}${item_total_profit.toLocaleString()} SA$</span>
                            <span class="item-chevron">▼</span>
                        </div>
                    </div>
                    <div class="item-details">
            `;

            positions.forEach(pos => {
                html += `
                    <div class="detail-line ${pos.profit >= 0 ? 'profit-ok' : 'profit-bad'}">
                        <div class="detail-line-left">
                            <span class="detail-name">${pos.name} ×${pos.quantity}</span>
                            <span class="detail-buy">Куплено: ${pos.buy_price.toLocaleString()} SA$ · ${pos.buy_price_per_unit.toLocaleString()} SA$/шт</span>
                        </div>
                        <div class="detail-line-right">
                            <span class="detail-lavka">${pos.lavka_price.toLocaleString()} VC$ · ${pos.lavka_count} шт</span>
                            <span class="detail-profit ${pos.profit >= 0 ? 'pos' : 'neg'}">${pos.profit >= 0 ? '+' : ''}${pos.profit.toLocaleString()} SA$</span>
                        </div>
                    </div>
                `;
            });

            html += `</div></div>`;
        });

        html += `</div></div>`;
    });

    content.innerHTML = html;
}

function toggleItemRow(id) {
    document.getElementById(id).classList.toggle('open');
}

// ─── Render Arbitrage ───────────────────────────────────────
function updateArbitrageContent(data) {
    const deals = data.cross5 || [];
    const statusText = data.status + (data.last_update ? ' · ' + data.last_update : '');
    setStatus('arbitrage-status', deals.length ? 'ok' : '', statusText);

    const content = document.getElementById('arbitrage-content');

    if (!deals.length) {
        content.innerHTML = '<div class="empty-state"><p>Нет арбитражных сделок 5→0</p></div>';
        return;
    }

    const buyGroups = {};
    deals.forEach(deal => {
        if (!buyGroups[deal.lavka_buy]) buyGroups[deal.lavka_buy] = [];
        buyGroups[deal.lavka_buy].push(deal);
    });

    const sortedLavkas = Object.keys(buyGroups)
        .map(id => ({ id, profit: buyGroups[id].reduce((s, d) => s + d.total_profit, 0) }))
        .sort((a, b) => b.profit - a.profit)
        .map(x => x.id);

    let html = `
        <div class="arb-section-header">
            Арбитраж 5→0 — ${deals.length} сделок · Купить на сервере 5, продать на сервере 0
        </div>
    `;

    sortedLavkas.forEach(buyLavka => {
        const groupDeals = [...buyGroups[buyLavka]].sort((a, b) => b.total_profit - a.total_profit);
        const groupProfit = groupDeals.reduce((s, d) => s + d.total_profit, 0);

        html += `
            <div class="arb-card">
                <div class="arb-head">
                    <div class="arb-icon">⇄</div>
                    <span class="arb-id">Лавка #${buyLavka} <span style="color:var(--text-muted);font-weight:400;font-size:12px;">серв. 5</span></span>
                    <span class="arb-count">${groupDeals.length} сделок</span>
                    <span class="arb-total">+${groupProfit.toLocaleString()} SA$</span>
                </div>
                <div class="table-wrap">
                    <table class="arb-table">
                        <thead>
                            <tr>
                                <th>Продать в лавку</th>
                                <th>Предмет</th>
                                <th>Цена покупки</th>
                                <th>Цена продажи</th>
                                <th>Профит/шт</th>
                                <th>Итого</th>
                                <th>Кол-во</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
        `;

        groupDeals.slice(0, 20).forEach(deal => {
            html += `
                <tr>
                    <td class="td-sell">#${deal.lavka_sell}</td>
                    <td class="td-item" title="${deal.item}">${deal.item.slice(0, 28)}${deal.item.length > 28 ? '…' : ''}</td>
                    <td class="td-num">${deal.price_buy.toLocaleString()}</td>
                    <td class="td-num">${deal.price_sell.toLocaleString()}</td>
                    <td class="td-profit">+${deal.profit.toLocaleString()}</td>
                    <td class="td-profit">+${deal.total_profit.toLocaleString()} SA$</td>
                    <td class="td-num">${deal.count_buy}</td>
                    <td class="td-action"><button class="btn-copy-small" onclick="copyToClipboard('/findilavka ${deal.lavka_sell}')">копировать</button></td>
                </tr>
            `;
        });

        html += `</tbody></table>`;
        if (groupDeals.length > 20) {
            html += `<div class="more-deals">+${groupDeals.length - 20} ещё сделок</div>`;
        }
        html += `</div></div>`;
    });

    content.innerHTML = html;
}

// ─── Copy utility ───────────────────────────────────────────
function copyToClipboard(text) {
    const btn = event.currentTarget;
    navigator.clipboard.writeText(text).then(() => {
        const orig = btn.textContent;
        btn.textContent = 'скопировано';
        btn.style.color = 'var(--green)';
        btn.style.borderColor = 'rgba(16,185,129,0.4)';
        setTimeout(() => {
            btn.textContent = orig;
            btn.style.color = '';
            btn.style.borderColor = '';
        }, 1500);
    });
}

// ─── Init ───────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
    initCanvas();

    // Close modal on backdrop click
    document.getElementById('inventoryModal').addEventListener('click', function(e) {
        if (e.target === this) closeInventoryModal();
    });

    // Poll auto-status every 5s
    async function pollStatus() {
        try {
            const res = await fetch('/api/auto_status');
            const status = await res.json();

            const scanBtn = document.getElementById('auto-scanner-btn');
            const scanDot = document.getElementById('dot-scanner');
            if (status.scanner_running) {
                scanBtn.classList.add('active');
                scanBtn.querySelector('.toggle-label').textContent = 'Автоскан: ВКЛ';
                scanDot.classList.add('on');
            }

            const arbBtn = document.getElementById('auto-arbitrage-btn');
            const arbDot = document.getElementById('dot-arbitrage');
            if (status.arbitrage_running) {
                arbBtn.classList.add('active');
                arbBtn.querySelector('.toggle-label').textContent = 'Автоарби: ВКЛ';
                arbDot.classList.add('on');
            }
        } catch(e) {}
    }

    setInterval(pollStatus, 5000);

    // Auto-reload scanner data every 30s
    setInterval(() => {
        if (document.getElementById('scanner').classList.contains('active')) loadScanner();
    }, 30000);

    // Wire up toggle buttons
    document.getElementById('auto-scanner-btn').onclick = toggleAutoScanner;
    document.getElementById('auto-arbitrage-btn').onclick = toggleAutoArbitrage;

    // Initial load
    loadScanner();
    toggleAutoScanner();
    toggleAutoArbitrage();
});
