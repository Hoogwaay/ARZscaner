# Arizona Scanner v3.0

## Overview
A Python Flask web application for scanning marketplace data from the Arizona online game. It provides:
- **Продажа (Sales Scanner):** Scans marketplace shops (lavki) and shows profitable items from your inventory to sell.
- **Арбитраж (Arbitrage):** Detects cross-server arbitrage opportunities between server 0 and server 5.
- **Инвентарь (Inventory):** Manages your item inventory stored in `inventory.json`.

## Architecture
- **Backend:** Python 3.11 + Flask 3.0.3
- **Frontend:** HTML/CSS/JS templates served by Flask
- **Data storage:** `inventory.json` (local JSON file)
- **External APIs:**
  - `https://server-api.arizona.games/client/json/table/get` — Item data
  - `https://api.arz.market/api/getSelectedMarketplace/-1` — Marketplace data

## Key Files
- `app.py` — Main Flask application with all routes and logic
- `run.py` — Launcher script with startup messages
- `inventory.json` — Persistent inventory storage
- `templates/index.html` — Main UI template
- `static/css/style.css` — Styles
- `static/js/main.js` — Frontend JavaScript

## Running
- **Dev:** `python run.py` (starts on port 5000)
- **Production:** `gunicorn --bind=0.0.0.0:5000 --reuse-port app:app`

## Configuration (app.py)
- `SA_TO_VC_RATE` — SA to VC conversion rate
- `VC_TO_SA_RATE` — VC to SA conversion rate (default: 107)
- `SELL_COMMISSION` — Commission rate (default: 0.91 = 9% fee)
