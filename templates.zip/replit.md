# Arizona Arbitrage Scanner (ARZARBITR)

## Project Overview
A Flask-based web application for scanning arbitrage opportunities in the Arizona (GTA San Andreas SAMP server) marketplace. It monitors the arz.market API and arizona.games API to find profitable cross-server trading opportunities.

## Tech Stack
- **Language:** Python 3.11
- **Framework:** Flask 3.0.3
- **HTTP Client:** requests 2.32.3
- **Production Server:** gunicorn

## Project Structure
```
/
├── app.py                  # Main Flask application (all routes + scanning logic)
├── chatlog_scanner.py      # Standalone chatlog parser (for local Windows use)
├── inventory.json          # Local inventory data store (JSON)
├── requirements.txt        # Python dependencies
├── templates/
│   └── index.html          # Main UI template
├── static/
│   ├── css/style.css       # Styles
│   └── js/main.js          # Frontend JS
```

## Key Features
- **Scanner tab:** Scans inventory items against marketplace offers to find sell opportunities
- **Arbitrage tab:** Finds cross-server (server 5 → server 0) arbitrage deals
- **Auto-scan:** Background threads refresh data every 30s (scanner) and 15s (arbitrage)
- **Inventory management:** Reads from `inventory.json` populated by chatlog scanner

## Configuration
- `INVENTORY_FILE`: Path to inventory JSON (`inventory.json`)
- `ITEMS_URL`: Arizona games items API
- `MARKETPLACE_URL`: ARZ market API
- `SA_TO_VC_RATE`, `VC_TO_SA_RATE`, `SELL_COMMISSION`: Exchange rate constants

## Running
- **Dev:** `python3 app.py` (port 5000, host 0.0.0.0)
- **Production:** `gunicorn --bind=0.0.0.0:5000 --reuse-port app:app`
