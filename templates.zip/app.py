import requests
from flask import Flask, render_template, request, jsonify, make_response
from datetime import datetime, date
from collections import defaultdict
import time
import json
import threading
import os

app = Flask(__name__)

INVENTORY_FILE = "inventory.json"
BALANCE_FILE = "balance.json"
ITEMS_URL = "https://server-api.arizona.games/client/json/table/get?project=arizona&server=0&key=inventory_items"
MARKETPLACE_URL = "https://api.arz.market/api/getSelectedMarketplace/-1"

SA_TO_VC_RATE = 1 / 100
VC_TO_SA_RATE = 107
SELL_COMMISSION = 0.91

arbitrage_data = {'cross5': [], 'last_update': None, 'status': 'Ожидание...'}
arbitrage_lock = threading.Lock()

arbitrage_0to0_data = {'deals': [], 'last_update': None, 'status': 'Ожидание...'}
arbitrage_0to0_lock = threading.Lock()

scanner_data = None
scanner_lock = threading.Lock()

auto_scanner_running = False
auto_arbitrage_running = False
auto_arbitrage_0to0_running = False


# ─── Inventory ──────────────────────────────────────────────────────────────

def load_inventory():
    if not os.path.exists(INVENTORY_FILE):
        return {}
    try:
        with open(INVENTORY_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except:
        return {}


def get_items_data_from_json():
    inventory = load_inventory()
    items_data = []
    for item_name, data in inventory.items():
        total_qty = data.get('qty', 0)
        entries = data.get('entries', [])
        if total_qty <= 0 or not entries:
            continue
        total_cost = sum(entry.get('qty', 0) * entry.get('price_per_unit', 0) for entry in entries)
        avg_price_per_unit = total_cost / total_qty if total_qty > 0 else 0
        min_sell_price = min((entry.get('price_per_unit', 0) for entry in entries), default=0)
        min_sell_price = int(min_sell_price * 1.1) if min_sell_price > 0 else 0
        items_data.append({
            'name': item_name,
            'quantity': total_qty,
            'buy_price': int(total_cost),
            'buy_price_per_unit': int(avg_price_per_unit),
            'min_sell_price': min_sell_price,
            'entries': entries
        })
    return items_data


def get_inventory_summary():
    inventory = load_inventory()
    items_list = []
    total_items = 0
    total_cost = 0
    for item_name, data in inventory.items():
        qty = data.get('qty', 0)
        if qty > 0:
            total_cost_item = sum(
                entry.get('qty', 0) * entry.get('price_per_unit', 0) for entry in data.get('entries', []))
            items_list.append({'name': item_name, 'qty': qty, 'total_cost': int(total_cost_item)})
            total_items += qty
            total_cost += total_cost_item
    return {
        'items': items_list,
        'total_items': total_items,
        'total_cost': int(total_cost),
        'item_types': len(items_list)
    }


# ─── Balance DB ─────────────────────────────────────────────────────────────

def load_balance():
    if not os.path.exists(BALANCE_FILE):
        return []
    try:
        with open(BALANCE_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except:
        return []


def save_balance(records):
    with open(BALANCE_FILE, 'w', encoding='utf-8') as f:
        json.dump(records, f, ensure_ascii=False, indent=2)


# ─── API fetch helpers ───────────────────────────────────────────────────────

def fetch_with_retry(url, retries=3, timeout=15):
    for attempt in range(1, retries + 1):
        try:
            resp = requests.get(url, timeout=timeout)
            resp.raise_for_status()
            return resp.json()
        except:
            pass
        if attempt < retries:
            time.sleep(min(2 ** attempt, 10))
    return []


# ─── Scanner (Продажа из инвентаря) ─────────────────────────────────────────

def scan_scanner():
    global scanner_data
    try:
        with scanner_lock:
            items_data_api = fetch_with_retry(ITEMS_URL, retries=3, timeout=20)
            lavki_data = fetch_with_retry(MARKETPLACE_URL, retries=3, timeout=20)
            all_lavki = [l for l in lavki_data if l.get('serverId') == 0]
            sheet_items = get_items_data_from_json()
            item_offers = []

            def get_item_id_by_name(item_name, items_data):
                for item in items_data:
                    if item['name'].strip().lower() == item_name.strip().lower():
                        return item['id']
                return None

            def find_all_lavki_for_item(item_id, all_lavki):
                offers = []
                for lavka in all_lavki:
                    items_buy = lavka.get('items_buy', [])
                    price_buy = lavka.get('price_buy', [])
                    count_buy = lavka.get('count_buy', [])
                    for i, buy_item in enumerate(items_buy):
                        if (str(buy_item).split('(')[0] == str(item_id) and
                                i < len(price_buy) and i < len(count_buy) and count_buy[i] > 0):
                            offers.append({
                                'lavka_uid': lavka['LavkaUid'],
                                'price': price_buy[i],
                                'count': count_buy[i]
                            })
                return sorted(offers, key=lambda x: x['price'], reverse=True)

            def calculate_profit(buy_price_sa_total, lavka_price_vc_per_unit, quantity):
                buy_price_sa_per_unit = buy_price_sa_total // quantity if quantity > 0 else 0
                clean_vc_after_commission = lavka_price_vc_per_unit * SELL_COMMISSION
                clean_sa_per_unit = clean_vc_after_commission * VC_TO_SA_RATE
                profit_sa_per_unit = clean_sa_per_unit - buy_price_sa_per_unit
                return int(profit_sa_per_unit * quantity)

            for json_item in sheet_items:
                item_name = json_item['name']
                item_id = get_item_id_by_name(item_name, items_data_api)
                if item_id:
                    offers = find_all_lavki_for_item(item_id, all_lavki)
                    if offers:
                        best_offer = offers[0]
                        profit = calculate_profit(
                            json_item['buy_price'],
                            best_offer['price'],
                            json_item['quantity']
                        )
                        item_offers.append({
                            'name': item_name,
                            'quantity': json_item['quantity'],
                            'buy_price': json_item['buy_price'],
                            'buy_price_per_unit': json_item['buy_price_per_unit'],
                            'min_sell_price': json_item['min_sell_price'],
                            'lavka_uid': best_offer['lavka_uid'],
                            'lavka_price': best_offer['price'],
                            'lavka_count': best_offer['count'],
                            'profit': profit,
                            'entries': json_item['entries']
                        })

            lavka_item_groups = defaultdict(lambda: defaultdict(list))
            total_stats = {'total_profit': 0, 'total_items': 0, 'lavka_count': 0, 'item_groups': 0}

            for item in item_offers:
                lavka_uid = item['lavka_uid']
                item_name = item['name']
                lavka_item_groups[lavka_uid][item_name].append(item)
                total_stats['total_profit'] += item['profit']
                total_stats['total_items'] += 1

            total_stats['item_groups'] = sum(len(items) for items in lavka_item_groups.values())
            sorted_lavki = sorted(lavka_item_groups.items(),
                                  key=lambda x: max(item['lavka_price'] for items in x[1].values() for item in items),
                                  reverse=True)
            total_stats['lavka_count'] = len(sorted_lavki)
            scanner_data = (sorted_lavki, total_stats)
    except Exception as e:
        with scanner_lock:
            scanner_data = None


# ─── Arbitrage 5→0 ──────────────────────────────────────────────────────────

def scan_arbitrage():
    global arbitrage_data
    try:
        with arbitrage_lock:
            arbitrage_data['status'] = '⏳ Сканирую...'
            lavki = requests.get(MARKETPLACE_URL, timeout=15).json()
            if not lavki:
                arbitrage_data['status'] = '❌ Ошибка API'
                return

            items_data = fetch_with_retry(ITEMS_URL, retries=2, timeout=15)
            items_db = {int(item['id']): item['name'] for item in items_data}

            server0_map = {l['LavkaUid']: l for l in lavki if l['serverId'] == 0}
            server5_map = {l['LavkaUid']: l for l in lavki if l['serverId'] == 5}

            def calculate_profit_cross(price_buy, price_sell):
                return ((price_sell / 100) * 91) * 107 - price_buy

            # Count how many server 0 lavkas are willing to buy each item
            item_sell_lavka_count = defaultdict(set)
            best_sell_prices = {}
            for lavka_uid, data in server0_map.items():
                if not data.get('items_buy') or not data.get('price_buy'):
                    continue
                for idx, item_id in enumerate(data['items_buy']):
                    try:
                        price = float(data['price_buy'][idx])
                        count = data['count_buy'][idx]
                        item_sell_lavka_count[item_id].add(lavka_uid)
                        if item_id not in best_sell_prices or price > best_sell_prices[item_id][0]:
                            best_sell_prices[item_id] = (price, lavka_uid, count)
                    except:
                        continue

            opportunities = []
            exclude_words = ["maketbones"]
            for item_id, (best_sell_price, best_sell_lavka, best_sell_count) in best_sell_prices.items():
                item_name_lower = items_db.get(item_id, f"ID_{item_id}").lower()
                if any(w in item_name_lower for w in exclude_words):
                    continue
                for buy_lavka_uid, buy_data in server5_map.items():
                    if buy_lavka_uid == best_sell_lavka:
                        continue
                    if not buy_data.get("items_sell") or not buy_data.get("price_sell"):
                        continue
                    for buy_idx, buy_item_id in enumerate(buy_data["items_sell"]):
                        if buy_item_id == item_id:
                            try:
                                buy_price = float(buy_data["price_sell"][buy_idx])
                                buy_count = buy_data["count_sell"][buy_idx]
                                profit = calculate_profit_cross(buy_price, best_sell_price)
                                if profit > 100:
                                    total_profit = int(profit * min(buy_count, best_sell_count))
                                    opportunities.append({
                                        "lavka_buy": buy_lavka_uid,
                                        "lavka_sell": best_sell_lavka,
                                        "item": items_db.get(item_id, f"ID_{item_id}"),
                                        "item_id": item_id,
                                        "price_buy": int(buy_price),
                                        "price_sell": int(best_sell_price),
                                        "profit": int(profit),
                                        "total_profit": total_profit,
                                        "count_buy": min(buy_count, best_sell_count),
                                        "sell_lavka_count": len(item_sell_lavka_count[item_id]),
                                    })
                            except:
                                continue

            final_opportunities = sorted(opportunities, key=lambda x: x['total_profit'], reverse=True)
            arbitrage_data.update({
                'cross5': final_opportunities,
                'last_update': time.strftime('%H:%M:%S'),
                'timestamp': int(time.time()),
                'status': f'✅ Готово! {len(final_opportunities)} сделок 5→0'
            })
    except Exception as e:
        with arbitrage_lock:
            arbitrage_data['status'] = f'❌ {str(e)}'


# ─── Arbitrage 0→0 ──────────────────────────────────────────────────────────

def scan_arbitrage_0to0():
    global arbitrage_0to0_data
    try:
        with arbitrage_0to0_lock:
            arbitrage_0to0_data['status'] = '⏳ Сканирую...'
            lavki = requests.get(MARKETPLACE_URL, timeout=15).json()
            if not lavki:
                arbitrage_0to0_data['status'] = '❌ Ошибка API'
                return

            items_data = fetch_with_retry(ITEMS_URL, retries=2, timeout=15)
            items_db = {int(item['id']): item['name'] for item in items_data}

            server0_lavki = [l for l in lavki if l.get('serverId') == 0]

            # item_id -> all offers from shops willing to buy (items_buy)
            item_buy_offers = defaultdict(list)
            for lavka in server0_lavki:
                items_buy = lavka.get('items_buy', []) or []
                price_buy = lavka.get('price_buy', []) or []
                count_buy = lavka.get('count_buy', []) or []
                for idx, item_id in enumerate(items_buy):
                    try:
                        price = float(price_buy[idx])
                        count = int(count_buy[idx])
                        if count > 0 and price > 0:
                            item_buy_offers[item_id].append({
                                'lavka_uid': lavka['LavkaUid'],
                                'price': price,
                                'count': count
                            })
                    except:
                        continue

            # item_id -> all offers from shops selling to you (items_sell)
            item_sell_offers = defaultdict(list)
            for lavka in server0_lavki:
                items_sell = lavka.get('items_sell', []) or []
                price_sell = lavka.get('price_sell', []) or []
                count_sell = lavka.get('count_sell', []) or []
                for idx, item_id in enumerate(items_sell):
                    try:
                        price = float(price_sell[idx])
                        count = int(count_sell[idx])
                        if count > 0 and price > 0:
                            item_sell_offers[item_id].append({
                                'lavka_uid': lavka['LavkaUid'],
                                'price': price,
                                'count': count
                            })
                    except:
                        continue

            opportunities = []
            exclude_words = ["maketbones"]
            all_item_ids = set(item_buy_offers.keys()) & set(item_sell_offers.keys())

            for item_id in all_item_ids:
                item_name_lower = items_db.get(item_id, f"ID_{item_id}").lower()
                if any(w in item_name_lower for w in exclude_words):
                    continue

                buy_offers = item_buy_offers[item_id]    # shops that buy from me
                sell_offers = item_sell_offers[item_id]  # shops that sell to me

                best_buy = max(buy_offers, key=lambda x: x['price'])    # best price shop pays me
                cheapest_sell = min(sell_offers, key=lambda x: x['price'])  # cheapest I can buy

                if best_buy['lavka_uid'] == cheapest_sell['lavka_uid']:
                    continue

                price_buy_from = cheapest_sell['price']   # price I pay to buy item (VC)
                price_sell_to = best_buy['price']          # price shop pays me (VC)

                # Profit in VC$ (no SA$ conversion for 0→0)
                # profit_vc = (price_sell_to / 100 * 91) - price_buy_from
                profit_vc = (price_sell_to / 100 * 91) - price_buy_from

                if profit_vc <= 0:
                    continue

                qty = min(cheapest_sell['count'], best_buy['count'])
                total_profit_vc = int(profit_vc * qty)
                if total_profit_vc <= 0:
                    continue

                opportunities.append({
                    "lavka_buy_from": cheapest_sell['lavka_uid'],
                    "lavka_sell_to": best_buy['lavka_uid'],
                    "item": items_db.get(item_id, f"ID_{item_id}"),
                    "item_id": item_id,
                    "price_buy_from": int(price_buy_from),
                    "price_sell_to": int(price_sell_to),
                    "profit_per_unit": round(profit_vc, 2),
                    "total_profit": total_profit_vc,
                    "count": qty,
                    "buy_lavka_count": len(buy_offers),
                })

            final_opportunities = sorted(opportunities, key=lambda x: x['total_profit'], reverse=True)
            arbitrage_0to0_data.update({
                'deals': final_opportunities,
                'last_update': time.strftime('%H:%M:%S'),
                'timestamp': int(time.time()),
                'status': f'✅ Готово! {len(final_opportunities)} сделок 0→0'
            })
    except Exception as e:
        with arbitrage_0to0_lock:
            arbitrage_0to0_data['status'] = f'❌ {str(e)}'


# ─── Auto loops ──────────────────────────────────────────────────────────────

def auto_scanner_loop():
    global auto_scanner_running
    while auto_scanner_running:
        try:
            scan_scanner()
            time.sleep(30)
        except:
            time.sleep(5)


def auto_arbitrage_loop():
    global auto_arbitrage_running
    while auto_arbitrage_running:
        try:
            scan_arbitrage()
            time.sleep(15)
        except:
            time.sleep(5)


def auto_arbitrage_0to0_loop():
    global auto_arbitrage_0to0_running
    while auto_arbitrage_0to0_running:
        try:
            scan_arbitrage_0to0()
            time.sleep(20)
        except:
            time.sleep(5)


# ─── Routes ──────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template('index.html')


@app.route("/api/scanner")
def api_scanner():
    with scanner_lock:
        if scanner_data:
            return jsonify({'success': True, 'data': scanner_data})
        return jsonify({'success': False, 'error': 'Нет данных'})


@app.route("/api/arbitrage")
def api_arbitrage():
    with arbitrage_lock:
        return jsonify({'success': True, 'data': arbitrage_data})


@app.route("/api/arbitrage_0to0")
def api_arbitrage_0to0():
    with arbitrage_0to0_lock:
        return jsonify({'success': True, 'data': arbitrage_0to0_data})


@app.route("/api/inventory")
def api_inventory():
    inventory = load_inventory()
    return jsonify({'success': True, 'data': inventory})


@app.route("/api/inventory-summary")
def api_inventory_summary():
    summary = get_inventory_summary()
    resp = make_response(jsonify({'success': True, 'data': summary}))
    resp.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    resp.headers['Pragma'] = 'no-cache'
    resp.headers['Expires'] = '0'
    return resp


@app.route("/api/search-items")
def api_search_items():
    query = request.args.get('q', '').lower()
    try:
        items = fetch_with_retry(ITEMS_URL, retries=2)
        filtered = [item for item in items if query in item.get('name', '').lower()]
        return jsonify({'success': True, 'items': filtered[:20]})
    except:
        return jsonify({'success': False, 'items': []})


@app.route("/api/add-item", methods=["POST"])
def api_add_item():
    try:
        data = request.json
        item_name = data.get('name', '')
        qty = int(data.get('qty', 0))
        price_per_unit = int(data.get('price_per_unit', 0))
        if not item_name or qty <= 0:
            return jsonify({'success': False, 'error': 'Invalid data'})
        inventory = load_inventory()
        if item_name not in inventory:
            inventory[item_name] = {'qty': 0, 'entries': []}
        entry = {
            'qty': qty,
            'price_per_unit': price_per_unit,
            'seller': 'Admin',
            'time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        inventory[item_name]['qty'] += qty
        inventory[item_name]['entries'].append(entry)
        with open(INVENTORY_FILE, 'w', encoding='utf-8') as f:
            json.dump(inventory, f, ensure_ascii=False, indent=2)
        return jsonify({'success': True, 'message': 'Item added'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route("/api/delete-item", methods=["POST"])
def api_delete_item():
    try:
        data = request.json
        item_name = data.get('name', '')
        if not item_name:
            return jsonify({'success': False, 'error': 'Invalid data'})
        inventory = load_inventory()
        if item_name in inventory:
            del inventory[item_name]
            with open(INVENTORY_FILE, 'w', encoding='utf-8') as f:
                json.dump(inventory, f, ensure_ascii=False, indent=2)
            return jsonify({'success': True, 'message': 'Item deleted'})
        else:
            return jsonify({'success': False, 'error': 'Item not found'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route("/api/auto_status")
def api_auto_status():
    return jsonify({
        'scanner_running': auto_scanner_running,
        'arbitrage_running': auto_arbitrage_running,
        'arbitrage_0to0_running': auto_arbitrage_0to0_running
    })


# ─── Balance API ─────────────────────────────────────────────────────────────

@app.route("/api/balance/add", methods=["POST"])
def api_balance_add():
    try:
        data = request.json
        amount = data.get('amount')
        note = data.get('note', '')
        if amount is None:
            return jsonify({'success': False, 'error': 'amount required'})
        amount = int(amount)
        records = load_balance()
        record = {
            'amount': amount,
            'note': note,
            'time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'date': date.today().isoformat()
        }
        records.append(record)
        save_balance(records)
        return jsonify({'success': True, 'record': record})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route("/api/balance/delete", methods=["POST"])
def api_balance_delete():
    try:
        data = request.json
        index = data.get('index')
        records = load_balance()
        if index is None or index < 0 or index >= len(records):
            return jsonify({'success': False, 'error': 'Invalid index'})
        records.pop(index)
        save_balance(records)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route("/api/balance/history")
def api_balance_history():
    try:
        records = load_balance()
        today = date.today().isoformat()
        income_today = 0
        income_all = 0
        if records:
            first_amount = records[0]['amount']
            last_amount = records[-1]['amount']
            income_all = last_amount - first_amount
            today_records = [r for r in records if r.get('date') == today]
            if len(today_records) >= 2:
                income_today = today_records[-1]['amount'] - today_records[0]['amount']
            elif len(today_records) == 1:
                prev = [r for r in records if r.get('date') < today]
                if prev:
                    income_today = today_records[-1]['amount'] - prev[-1]['amount']
        return jsonify({
            'success': True,
            'records': records,
            'income_today': income_today,
            'income_all': income_all
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


# ─── Scan / toggle routes ─────────────────────────────────────────────────────

@app.route("/scan_scanner", methods=["POST"])
def scan_scanner_route():
    thread = threading.Thread(target=scan_scanner)
    thread.daemon = True
    thread.start()
    return jsonify({'status': 'started'})


@app.route("/scan_arbitrage", methods=["POST"])
def scan_arbitrage_route():
    thread = threading.Thread(target=scan_arbitrage)
    thread.daemon = True
    thread.start()
    return jsonify({'status': 'started'})


@app.route("/scan_arbitrage_0to0", methods=["POST"])
def scan_arbitrage_0to0_route():
    thread = threading.Thread(target=scan_arbitrage_0to0)
    thread.daemon = True
    thread.start()
    return jsonify({'status': 'started'})


@app.route("/toggle_auto_scanner", methods=["POST"])
def toggle_auto_scanner():
    global auto_scanner_running
    if auto_scanner_running:
        auto_scanner_running = False
        return jsonify({'status': 'stopped', 'scanner_running': False})
    else:
        auto_scanner_running = True
        threading.Thread(target=auto_scanner_loop, daemon=True).start()
        return jsonify({'status': 'started', 'scanner_running': True})


@app.route("/toggle_auto_arbitrage", methods=["POST"])
def toggle_auto_arbitrage():
    global auto_arbitrage_running
    if auto_arbitrage_running:
        auto_arbitrage_running = False
        return jsonify({'status': 'stopped', 'arbitrage_running': False})
    else:
        auto_arbitrage_running = True
        threading.Thread(target=auto_arbitrage_loop, daemon=True).start()
        return jsonify({'status': 'started', 'arbitrage_running': True})


@app.route("/toggle_auto_arbitrage_0to0", methods=["POST"])
def toggle_auto_arbitrage_0to0():
    global auto_arbitrage_0to0_running
    if auto_arbitrage_0to0_running:
        auto_arbitrage_0to0_running = False
        return jsonify({'status': 'stopped', 'arbitrage_0to0_running': False})
    else:
        auto_arbitrage_0to0_running = True
        threading.Thread(target=auto_arbitrage_0to0_loop, daemon=True).start()
        return jsonify({'status': 'started', 'arbitrage_0to0_running': True})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
