"""
Arizona Scanner — Арбитраж сервер 27 (Bumble Bee) → Сервер 0
Курс продажи: 1 VC$ = 96 SA$
"""

from arbitrage_engine import scan_arbitrage_for_server

SERVER_ID   = 27
SERVER_NAME = "Bumble Bee"
SELL_RATE   = 96


def scan():
    """Запускает сканирование арбитража для сервера 27 → 0."""
    return scan_arbitrage_for_server(SERVER_ID, 0, SELL_RATE)
