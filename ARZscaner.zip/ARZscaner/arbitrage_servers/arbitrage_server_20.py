"""
Arizona Scanner — Арбитраж сервер 20 (Sun City) → Сервер 0
Курс продажи: 1 VC$ = 96 SA$
"""

from arbitrage_engine import scan_arbitrage_for_server

SERVER_ID   = 20
SERVER_NAME = "Sun City"
SELL_RATE   = 96


def scan():
    """Запускает сканирование арбитража для сервера 20 → 0."""
    return scan_arbitrage_for_server(SERVER_ID, 0, SELL_RATE)
