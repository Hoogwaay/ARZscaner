"""
Arizona Scanner — Арбитраж сервер 19 (Page) → Сервер 0
Курс продажи: 1 VC$ = 96 SA$
"""

from arbitrage_engine import scan_arbitrage_for_server

SERVER_ID   = 19
SERVER_NAME = "Page"
SELL_RATE   = 96


def scan():
    """Запускает сканирование арбитража для сервера 19 → 0."""
    return scan_arbitrage_for_server(SERVER_ID, 0, SELL_RATE)
