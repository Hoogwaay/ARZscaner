"""
Arizona Scanner — Арбитраж сервер 7 (Mesa) → Сервер 0
Курс продажи: 1 VC$ = 137 SA$
"""

from arbitrage_engine import scan_arbitrage_for_server

SERVER_ID   = 7
SERVER_NAME = "Mesa"
SELL_RATE   = 137


def scan():
    """Запускает сканирование арбитража для сервера 7 → 0."""
    return scan_arbitrage_for_server(SERVER_ID, 0, SELL_RATE)
