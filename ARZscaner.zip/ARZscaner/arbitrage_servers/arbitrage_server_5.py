"""
Arizona Scanner — Арбитраж сервер 5 (Brainburg) → Сервер 0
Курс продажи: 1 VC$ = 107 SA$
"""

from arbitrage_engine import scan_arbitrage_for_server

SERVER_ID   = 5
SERVER_NAME = "Brainburg"
SELL_RATE   = 107


def scan():
    """Запускает сканирование арбитража для сервера 5 → 0."""
    return scan_arbitrage_for_server(SERVER_ID, 0, SELL_RATE)
