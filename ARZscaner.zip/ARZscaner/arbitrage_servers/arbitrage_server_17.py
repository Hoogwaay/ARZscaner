"""
Arizona Scanner — Арбитраж сервер 17 (Show Low) → Сервер 0
Курс продажи: 1 VC$ = 96 SA$
"""

from arbitrage_engine import scan_arbitrage_for_server

SERVER_ID   = 17
SERVER_NAME = "Show Low"
SELL_RATE   = 96


def scan():
    """Запускает сканирование арбитража для сервера 17 → 0."""
    return scan_arbitrage_for_server(SERVER_ID, 0, SELL_RATE)
