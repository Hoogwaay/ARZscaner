"""
Arizona Scanner — Арбитраж сервер 32 (Space) → Сервер 0
Курс продажи: 1 VC$ = 96 SA$
"""

from arbitrage_engine import scan_arbitrage_for_server

SERVER_ID   = 32
SERVER_NAME = "Space"
SELL_RATE   = 96


def scan():
    """Запускает сканирование арбитража для сервера 32 → 0."""
    return scan_arbitrage_for_server(SERVER_ID, 0, SELL_RATE)
