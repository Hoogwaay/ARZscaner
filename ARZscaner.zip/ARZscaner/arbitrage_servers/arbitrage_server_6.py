"""
Arizona Scanner — Арбитраж сервер 6 (Saint Rose) → Сервер 0
Курс продажи: 1 VC$ = 106 SA$
"""

from arbitrage_engine import scan_arbitrage_for_server

SERVER_ID   = 6
SERVER_NAME = "Saint Rose"
SELL_RATE   = 106


def scan():
    """Запускает сканирование арбитража для сервера 6 → 0."""
    return scan_arbitrage_for_server(SERVER_ID, 0, SELL_RATE)
