"""
Arizona Scanner — Арбитраж сервер 3 (Scottdale) → Сервер 0
Курс продажи: 1 VC$ = 127 SA$
"""

from arbitrage_engine import scan_arbitrage_for_server

SERVER_ID   = 3
SERVER_NAME = "Scottdale"
SELL_RATE   = 127


def scan():
    """Запускает сканирование арбитража для сервера 3 → 0."""
    return scan_arbitrage_for_server(SERVER_ID, 0, SELL_RATE)
