"""
Arizona Scanner — Арбитраж сервер 9 (Yuma) → Сервер 0
Курс продажи: 1 VC$ = 113 SA$
"""

from arbitrage_engine import scan_arbitrage_for_server

SERVER_ID   = 9
SERVER_NAME = "Yuma"
SELL_RATE   = 113


def scan():
    """Запускает сканирование арбитража для сервера 9 → 0."""
    return scan_arbitrage_for_server(SERVER_ID, 0, SELL_RATE)
