"""
Arizona Scanner — Арбитраж сервер 8 (Red Rock) → Сервер 0
Курс продажи: 1 VC$ = 98 SA$
"""

from arbitrage_engine import scan_arbitrage_for_server

SERVER_ID   = 8
SERVER_NAME = "Red Rock"
SELL_RATE   = 98


def scan():
    """Запускает сканирование арбитража для сервера 8 → 0."""
    return scan_arbitrage_for_server(SERVER_ID, 0, SELL_RATE)
