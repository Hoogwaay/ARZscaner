import requests
import threading
import time
import json
import os
from collections import defaultdict
from datetime import datetime, date
from flask import Flask, render_template, request, jsonify, make_response
from arbitrage_engine import scan_arbitrage_for_server, fetch_lavki, fetch_items_db, scan_best_deals

app = Flask(__name__)

INVENTORY_FILE  = "inventory.json"
BALANCE_FILE    = "balance.json"
CURRENCY_FILE   = "currencyrate.json"
ITEMS_URL       = "https://server-api.arizona.games/client/json/table/get?project=arizona&server=0&key=inventory_items"
MARKETPLACE_URL = "https://api.arz.market/api/getSelectedMarketplace/-1"
SELL_COMMISSION = 0.91


# ─── Currency rates ───────────────────────────────────────────────────────────

def load_currency_rates():
    try:
        with open(CURRENCY_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return {s['id']: s for s in data['servers']}
    except Exception:
        return {}

CURRENCY_RATES = load_currency_rates()


# ─── Arbitrage state (keyed by "buy_sell") ────────────────────────────────────

arb_cache      = {}   # key: "buy_sell" → {deals, status, last_update, timestamp}
arb_cache_lock = threading.Lock()


# ─── Best deals state ─────────────────────────────────────────────────────────

bd_cache      = {'deals': [], 'status': 'Нажмите «Скан»', 'last_update': None, 'timestamp': None}
bd_cache_lock = threading.Lock()

def get_bd_state() -> dict:
    with bd_cache_lock:
        return dict(bd_cache)

def set_bd_state(state: dict):
    global bd_cache
    with bd_cache_lock:
        bd_cache = state

def arb_key(buy: int, sell: int) -> str:
    return f"{buy}_{sell}"

def get_arb_state(buy: int, sell: int) -> dict:
    with arb_cache_lock:
        return dict(arb_cache.get(arb_key(buy, sell), {
            'deals': [], 'status': 'Нажмите «Скан»', 'last_update': None, 'timestamp': None
        }))

def set_arb_state(buy: int, sell: int, state: dict):
    with arb_cache_lock:
        arb_cache[arb_key(buy, sell)] = state


# ─── Scanner state ────────────────────────────────────────────────────────────

scanner_data = None
scanner_lock = threading.Lock()

auto_scanner_running   = False
auto_arbitrage_running = False
auto_arb_buy  = 2
auto_arb_sell = 0


# ─── Inventory ────────────────────────────────────────────────────────────────

def load_inventory():
    if not os.path.exists(INVENTORY_FILE):
        return {}
    try:
        with open(INVENTORY_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def get_items_data_from_json():
    inventory = load_inventory()
    items_data = []
    for item_name, data in inventory.items():
        total_qty = data.get('qty', 0)
        entries   = data.get('entries', [])
        if total_qty <= 0 or not entries:
            continue
        total_cost = sum(e.get('qty', 0) * e.get('price_per_unit', 0) for e in entries)
        avg_price  = total_cost / total_qty if total_qty > 0 else 0
        min_sell   = min((e.get('price_per_unit', 0) for e in entries), default=0)
        min_sell   = int(min_sell * 1.1) if min_sell > 0 else 0
        items_data.append({
            'name':              item_name,
            'quantity':          total_qty,
            'buy_price':         int(total_cost),
            'buy_price_per_unit':int(avg_price),
            'min_sell_price':    min_sell,
            'entries':           entries,
        })
    return items_data


def get_inventory_summary():
    inventory = load_inventory()
    items_list, total_items, total_cost = [], 0, 0
    for item_name, data in inventory.items():
        qty = data.get('qty', 0)
        if qty > 0:
            cost = sum(e.get('qty', 0) * e.get('price_per_unit', 0) for e in data.get('entries', []))
            items_list.append({'name': item_name, 'qty': qty, 'total_cost': int(cost)})
            total_items += qty
            total_cost  += cost
    return {'items': items_list, 'total_items': total_items,
            'total_cost': int(total_cost), 'item_types': len(items_list)}


# ─── Balance ──────────────────────────────────────────────────────────────────

def load_balance():
    if not os.path.exists(BALANCE_FILE):
        return []
    try:
        with open(BALANCE_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return []

def save_balance(records):
    with open(BALANCE_FILE, 'w', encoding='utf-8') as f:
        json.dump(records, f, ensure_ascii=False, indent=2)


# ─── Fetch helper ─────────────────────────────────────────────────────────────

def fetch_with_retry(url, retries=3, timeout=15):
    for attempt in range(1, retries + 1):
        try:
            resp = requests.get(url, timeout=timeout)
            resp.raise_for_status()
            return resp.json()
        except Exception:
            pass
        if attempt < retries:
            time.sleep(min(2 ** attempt, 10))
    return []


# ─── Scanner (Продажа из инвентаря) ──────────────────────────────────────────

def scan_scanner():
    global scanner_data
    try:
        with scanner_lock:
            items_data_api = fetch_with_retry(ITEMS_URL, retries=3, timeout=20)
            lavki_data     = fetch_with_retry(MARKETPLACE_URL, retries=3, timeout=20)
            all_lavki      = [l for l in lavki_data if l.get('serverId') == 0]
            sheet_items    = get_items_data_from_json()

            def get_item_id_by_name(name, db):
                for item in db:
                    if item['name'].strip().lower() == name.strip().lower():
                        return item['id']
                return None

            def find_all_lavki_for_item(item_id, lavki):
                offers = []
                for lavka in lavki:
                    items_buy = lavka.get('items_buy', [])
                    price_buy = lavka.get('price_buy', [])
                    count_buy = lavka.get('count_buy', [])
                    for i, bid in enumerate(items_buy):
                        if (str(bid).split('(')[0] == str(item_id) and
                                i < len(price_buy) and i < len(count_buy) and count_buy[i] > 0):
                            offers.append({'lavka_uid': lavka['LavkaUid'],
                                           'price': price_buy[i], 'count': count_buy[i]})
                return sorted(offers, key=lambda x: x['price'], reverse=True)

            def calculate_profit(buy_price_sa_total, lavka_price_vc, quantity):
                buy_per_unit  = buy_price_sa_total // quantity if quantity > 0 else 0
                vc_after_comm = lavka_price_vc * SELL_COMMISSION
                sa_per_unit   = vc_after_comm * 107
                return int((sa_per_unit - buy_per_unit) * quantity)

            item_offers = []
            for json_item in sheet_items:
                item_id = get_item_id_by_name(json_item['name'], items_data_api)
                if item_id:
                    offers = find_all_lavki_for_item(item_id, all_lavki)
                    if offers:
                        best   = offers[0]
                        profit = calculate_profit(
                            json_item['buy_price'], best['price'], json_item['quantity'])
                        item_offers.append({
                            'name':              json_item['name'],
                            'quantity':          json_item['quantity'],
                            'buy_price':         json_item['buy_price'],
                            'buy_price_per_unit':json_item['buy_price_per_unit'],
                            'min_sell_price':    json_item['min_sell_price'],
                            'lavka_uid':         best['lavka_uid'],
                            'lavka_price':       best['price'],
                            'lavka_count':       best['count'],
                            'profit':            profit,
                            'entries':           json_item['entries'],
                        })

            lavka_item_groups = defaultdict(lambda: defaultdict(list))
            total_stats = {'total_profit': 0, 'total_items': 0,
                           'lavka_count': 0, 'item_groups': 0}
            for item in item_offers:
                lavka_item_groups[item['lavka_uid']][item['name']].append(item)
                total_stats['total_profit'] += item['profit']
                total_stats['total_items']  += 1

            total_stats['item_groups'] = sum(len(v) for v in lavka_item_groups.values())
            sorted_lavki = sorted(
                lavka_item_groups.items(),
                key=lambda x: max(i['lavka_price'] for items in x[1].values() for i in items),
                reverse=True)
            total_stats['lavka_count'] = len(sorted_lavki)
            scanner_data = (sorted_lavki, total_stats)
    except Exception:
        with scanner_lock:
            scanner_data = None


# ─── Arbitrage scan ───────────────────────────────────────────────────────────

def do_scan_arbitrage(buy_id: int, sell_id: int):
    set_arb_state(buy_id, sell_id, {
        'deals': [], 'status': '⏳ Сканирую...', 'last_update': None, 'timestamp': None
    })
    try:
        result = scan_arbitrage_for_server(buy_id, sell_id, CURRENCY_RATES)
        set_arb_state(buy_id, sell_id, result)
    except Exception as e:
        set_arb_state(buy_id, sell_id, {
            'deals': [], 'status': f'❌ {str(e)}', 'last_update': time.strftime('%H:%M:%S'), 'timestamp': None
        })


def do_scan_best_deals():
    set_bd_state({'deals': [], 'status': '⏳ Сканирую все серверы...', 'last_update': None, 'timestamp': None})
    try:
        result = scan_best_deals(CURRENCY_RATES)
        set_bd_state(result)
    except Exception as e:
        set_bd_state({'deals': [], 'status': f'❌ {str(e)}', 'last_update': time.strftime('%H:%M:%S'), 'timestamp': None})


# ─── Auto loops ───────────────────────────────────────────────────────────────

def auto_scanner_loop():
    global auto_scanner_running
    while auto_scanner_running:
        try:
            scan_scanner()
            time.sleep(30)
        except Exception:
            time.sleep(5)


def auto_arbitrage_loop():
    global auto_arbitrage_running
    while auto_arbitrage_running:
        try:
            do_scan_arbitrage(auto_arb_buy, auto_arb_sell)
            time.sleep(15)
        except Exception:
            time.sleep(5)


# ─── Routes ───────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template('index.html')


@app.route("/api/currency_rates")
def api_currency_rates():
    return jsonify({'success': True, 'rates': list(CURRENCY_RATES.values())})


@app.route("/api/scanner")
def api_scanner():
    with scanner_lock:
        if scanner_data:
            return jsonify({'success': True, 'data': scanner_data})
        return jsonify({'success': False, 'error': 'Нет данных'})


@app.route("/api/arbitrage")
def api_arbitrage():
    try:
        buy_id  = int(request.args.get('buy',  2))
        sell_id = int(request.args.get('sell', 0))
    except ValueError:
        buy_id, sell_id = 2, 0

    buy_id  = max(0, min(32, buy_id))
    sell_id = max(0, min(32, sell_id))

    state      = get_arb_state(buy_id, sell_id)
    buy_info   = CURRENCY_RATES.get(buy_id,  {})
    sell_info  = CURRENCY_RATES.get(sell_id, {})
    sell_rate  = sell_info.get('sell_rate', 1)

    return jsonify({
        'success':       True,
        'buy_id':        buy_id,
        'sell_id':       sell_id,
        'buy_name':      buy_info.get('name',  f'Сервер {buy_id}'),
        'sell_name':     sell_info.get('name', f'Сервер {sell_id}'),
        'sell_rate':     sell_rate,
        'data':          state,
    })


@app.route("/api/market")
def api_market():
    query     = request.args.get('q', '').strip().lower()
    server_id = int(request.args.get('server', 0))

    if not query:
        return jsonify({'success': False, 'error': 'Введите название товара'})

    lavki    = fetch_lavki()
    items_db = fetch_items_db()  # {item_id: name}

    if not lavki:
        return jsonify({'success': False, 'error': 'Нет данных от маркета'})

    # Reverse map: name → item_id
    name_to_ids = {}
    for iid, name in items_db.items():
        if query in name.lower():
            name_to_ids[iid] = name

    if not name_to_ids:
        return jsonify({'success': True, 'buy_shops': [], 'sell_shops': [], 'matched_items': []})

    matched_item_names = sorted(set(name_to_ids.values()))

    # Filter lavki by server
    server_lavki = [l for l in lavki if l.get('serverId') == server_id]

    buy_shops  = []  # lavkas that BUY from player (скупщики)
    sell_shops = []  # lavkas that SELL to player (продавцы)

    for l in server_lavki:
        lavka_uid = l.get('LavkaUid')

        # BUY shops: items_buy → player sells to lavka
        if l.get('items_buy') and l.get('price_buy'):
            for idx, item_id in enumerate(l['items_buy']):
                iid = item_id if isinstance(item_id, int) else None
                if iid is None:
                    try:
                        iid = int(str(item_id).split('(')[0])
                    except Exception:
                        continue
                if iid in name_to_ids:
                    try:
                        price_raw = float(l['price_buy'][idx])
                        count     = int(l['count_buy'][idx]) if l.get('count_buy') else 0
                        buy_shops.append({
                            'lavka_uid': lavka_uid,
                            'item_id':   iid,
                            'item_name': name_to_ids[iid],
                            'price':     int(price_raw),
                            'count':     count,
                        })
                    except Exception:
                        continue

        # SELL shops: items_sell → player buys from lavka
        if l.get('items_sell') and l.get('price_sell'):
            for idx, item_id in enumerate(l['items_sell']):
                iid = item_id if isinstance(item_id, int) else None
                if iid is None:
                    try:
                        iid = int(str(item_id).split('(')[0])
                    except Exception:
                        continue
                if iid in name_to_ids:
                    try:
                        price_raw = float(l['price_sell'][idx])
                        count     = int(l['count_sell'][idx]) if l.get('count_sell') else 0
                        sell_shops.append({
                            'lavka_uid': lavka_uid,
                            'item_id':   iid,
                            'item_name': name_to_ids[iid],
                            'price':     price_raw,
                            'count':     count,
                        })
                    except Exception:
                        continue

    return jsonify({
        'success':       True,
        'buy_shops':     buy_shops,
        'sell_shops':    sell_shops,
        'matched_items': matched_item_names,
        'server_id':     server_id,
        'query':         query,
    })


@app.route("/api/inventory")
def api_inventory():
    return jsonify({'success': True, 'data': load_inventory()})


@app.route("/api/inventory-summary")
def api_inventory_summary():
    resp = make_response(jsonify({'success': True, 'data': get_inventory_summary()}))
    resp.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    resp.headers['Pragma']        = 'no-cache'
    resp.headers['Expires']       = '0'
    return resp


@app.route("/api/search-items")
def api_search_items():
    query = request.args.get('q', '').lower()
    try:
        items    = fetch_with_retry(ITEMS_URL, retries=2)
        filtered = [i for i in items if query in i.get('name', '').lower()]
        return jsonify({'success': True, 'items': filtered[:20]})
    except Exception:
        return jsonify({'success': False, 'items': []})


@app.route("/api/add-item", methods=["POST"])
def api_add_item():
    try:
        data           = request.json
        item_name      = data.get('name', '')
        qty            = int(data.get('qty', 0))
        price_per_unit = int(data.get('price_per_unit', 0))
        if not item_name or qty <= 0:
            return jsonify({'success': False, 'error': 'Invalid data'})
        inventory = load_inventory()
        if item_name not in inventory:
            inventory[item_name] = {'qty': 0, 'entries': []}
        inventory[item_name]['qty'] += qty
        inventory[item_name]['entries'].append({
            'qty': qty, 'price_per_unit': price_per_unit,
            'seller': 'Admin', 'time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        })
        with open(INVENTORY_FILE, 'w', encoding='utf-8') as f:
            json.dump(inventory, f, ensure_ascii=False, indent=2)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route("/api/delete-item", methods=["POST"])
def api_delete_item():
    try:
        data      = request.json
        item_name = data.get('name', '')
        if not item_name:
            return jsonify({'success': False, 'error': 'Invalid data'})
        inventory = load_inventory()
        if item_name in inventory:
            del inventory[item_name]
            with open(INVENTORY_FILE, 'w', encoding='utf-8') as f:
                json.dump(inventory, f, ensure_ascii=False, indent=2)
            return jsonify({'success': True})
        return jsonify({'success': False, 'error': 'Item not found'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route("/api/auto_status")
def api_auto_status():
    return jsonify({
        'scanner_running':   auto_scanner_running,
        'arbitrage_running': auto_arbitrage_running,
        'arb_buy':           auto_arb_buy,
        'arb_sell':          auto_arb_sell,
    })


# ─── Balance ──────────────────────────────────────────────────────────────────

@app.route("/api/balance/add", methods=["POST"])
def api_balance_add():
    try:
        data    = request.json
        amount  = data.get('amount')
        note    = data.get('note', '')
        if amount is None:
            return jsonify({'success': False, 'error': 'amount required'})
        amount  = int(amount)
        records = load_balance()
        record  = {'amount': amount, 'note': note,
                   'time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                   'date': date.today().isoformat()}
        records.append(record)
        save_balance(records)
        return jsonify({'success': True, 'record': record})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route("/api/balance/delete", methods=["POST"])
def api_balance_delete():
    try:
        data    = request.json
        index   = data.get('index')
        records = load_balance()
        if index is None or index < 0 or index >= len(records):
            return jsonify({'success': False, 'error': 'Invalid index'})
        records.pop(index)
        save_balance(records)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route("/api/balance/history")
def api_balance_history():
    try:
        records     = load_balance()
        today       = date.today().isoformat()
        income_today, income_all = 0, 0
        if records:
            income_all  = records[-1]['amount'] - records[0]['amount']
            today_recs  = [r for r in records if r.get('date') == today]
            if len(today_recs) >= 2:
                income_today = today_recs[-1]['amount'] - today_recs[0]['amount']
            elif len(today_recs) == 1:
                prev = [r for r in records if r.get('date', '') < today]
                if prev:
                    income_today = today_recs[-1]['amount'] - prev[-1]['amount']
        return jsonify({'success': True, 'records': records,
                        'income_today': income_today, 'income_all': income_all})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


# ─── Scan / toggle routes ─────────────────────────────────────────────────────

@app.route("/scan_scanner", methods=["POST"])
def scan_scanner_route():
    threading.Thread(target=scan_scanner, daemon=True).start()
    return jsonify({'status': 'started'})


@app.route("/scan_arbitrage", methods=["POST"])
def scan_arbitrage_route():
    global auto_arb_buy, auto_arb_sell
    try:
        buy_id  = int(request.args.get('buy',  2))
        sell_id = int(request.args.get('sell', 0))
    except ValueError:
        buy_id, sell_id = 2, 0
    buy_id  = max(0, min(32, buy_id))
    sell_id = max(0, min(32, sell_id))
    auto_arb_buy  = buy_id
    auto_arb_sell = sell_id
    threading.Thread(target=do_scan_arbitrage, args=(buy_id, sell_id), daemon=True).start()
    return jsonify({'status': 'started', 'buy': buy_id, 'sell': sell_id})


@app.route("/toggle_auto_scanner", methods=["POST"])
def toggle_auto_scanner():
    global auto_scanner_running
    if auto_scanner_running:
        auto_scanner_running = False
        return jsonify({'status': 'stopped', 'scanner_running': False})
    else:
        auto_scanner_running = True
        threading.Thread(target=auto_scanner_loop, daemon=True).start()
        return jsonify({'status': 'started', 'scanner_running': True})


@app.route("/toggle_auto_arbitrage", methods=["POST"])
def toggle_auto_arbitrage():
    global auto_arbitrage_running, auto_arb_buy, auto_arb_sell
    try:
        body    = request.get_json(silent=True) or {}
        buy_id  = int(body.get('buy',  auto_arb_buy))
        sell_id = int(body.get('sell', auto_arb_sell))
    except Exception:
        buy_id, sell_id = auto_arb_buy, auto_arb_sell
    auto_arb_buy  = buy_id
    auto_arb_sell = sell_id
    if auto_arbitrage_running:
        auto_arbitrage_running = False
        return jsonify({'status': 'stopped', 'arbitrage_running': False})
    else:
        auto_arbitrage_running = True
        threading.Thread(target=auto_arbitrage_loop, daemon=True).start()
        return jsonify({'status': 'started', 'arbitrage_running': True})


@app.route("/api/best_deals")
def api_best_deals():
    return jsonify(get_bd_state())


@app.route("/scan_best_deals", methods=["POST"])
def scan_best_deals_route():
    threading.Thread(target=do_scan_best_deals, daemon=True).start()
    return jsonify({'status': 'started'})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
