# Arizona Scanner v3.0

## Overview
Python Flask web application for scanning marketplace data from the Arizona online game.

## Features
- **Продажа** — Scans marketplace (server 0) for profitable items from inventory.json
- **Арбитраж N→0** — Single arbitrage tab with server selector (servers 1–32). Each server scanned in a separate module, all run simultaneously in background threads.
- **Дашборд** — Balance history and profit chart
- **Инвентарь** — Manage owned items

## Architecture

### Key Files
- `app.py` — Flask app, routes, auto-scan loops
- `arbitrage_engine.py` — Shared N→0 arbitrage scan logic
- `arbitrage_servers/arbitrage_server_1.py` ... `arbitrage_server_32.py` — Per-server modules (SERVER_ID, SERVER_NAME, SELL_RATE + scan())
- `currencyrate.json` — Currency rates for all 32 servers (buy_rate, sell_rate)
- `inventory.json` — User's inventory
- `balance.json` — Balance history
- `run.py` — Entry point launcher

### Currency rates
Format: `{"servers": [{"id": N, "name": "...", "buy_rate": X, "sell_rate": Y}]}`
- `sell_rate` used in N→0 arbitrage: profit = (sell_price_vc * 0.91) * sell_rate - buy_price_sa

### Arbitrage Profit Formulas
Prices from the marketplace API are raw (VC$ on server 0, SA$ on servers 1-32). No /100 division needed.

| Direction | Formula |
|-----------|---------|
| N→0 (SA→VC) | `profit_sa = sell_price_vc * 0.91 * buy_server_sell_rate - buy_price_sa` |
| 0→N (VC→SA) | `profit_vc = sell_price_sa * 0.91 / sell_server_buy_rate - buy_price_vc` |
| N→M (SA→SA) | `profit_sa = (sell_price_sa * 0.91 / sell_buy_rate) * buy_sell_rate - buy_price_sa` |
| 0→0 (VC→VC) | `profit_vc = sell_price_vc * 0.91 - buy_price_vc` |

`profit_pct = profit / buy_price * 100`

## Setup
- **Runtime**: Python 3.11
- **Packages**: Flask==3.0.3, requests==2.32.3, gunicorn
- **Workflow**: "Start application" → `python run.py` on port 5000 (webview)
- **Deployment**: VM target, gunicorn `--bind=0.0.0.0:5000 --reuse-port --workers=2 app:app`
  - Uses VM (not autoscale) because the app uses threading and in-memory state for auto-scan loops

## Arbitrage Engine
- Supports all 33 servers (0–32); server 0 = Vice City (sell_rate = 1)
- Default buy server: 0 (Vice City) — cheapest source
- Default sell server: 2 (Tucson, rate = 156 SA$/VC$) — profitable destination
- The profitable direction is always buy on Vice City, sell on SA servers (not the other way)
- `arbitrage_servers/` directory contains 32 legacy per-server files (not used by main app — use engine directly)

## Important Notes
- App host must be `0.0.0.0` and port `5000` for Replit preview to work
- The `global` declarations in `app.py` must appear before any variable usage within their function scope
- Prices in the marketplace API are in VC$ cents (divide by 100 to get VC$, then × sell_rate to get SA$)
