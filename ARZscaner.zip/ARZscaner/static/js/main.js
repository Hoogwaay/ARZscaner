// Route66 Market — v3.0

let scannerLoading   = false;
let arbitrageLoading = false;

// Arbitrage filters
let arbFilters        = { minProfit: 0, minLavkas: 0, excludedItems: [] };
let lastArbitrageData = null;

// Currency rates loaded from server
let currencyRates      = [];
let selectedBuyServer  = 0;
let selectedSellServer = 2;

// User's personal server (for header rate display)
let userServer = 2;

// ─── Loader ──────────────────────────────────────────────────
function initLoader() {
    const loader = document.getElementById('loader');
    if (!loader) return;
    const minTime = 1900;
    const start   = Date.now();
    function hide() {
        const elapsed = Date.now() - start;
        const delay   = Math.max(0, minTime - elapsed);
        setTimeout(() => loader.classList.add('hidden'), delay);
    }
    if (document.readyState === 'complete') {
        hide();
    } else {
        window.addEventListener('load', hide);
    }
}

// ─── User server preference ───────────────────────────────────
function loadUserServer() {
    try {
        const saved = localStorage.getItem('userServer');
        if (saved !== null) userServer = parseInt(saved) || 2;
    } catch(e) {}
}

function saveUserServer(serverId) {
    userServer = serverId;
    try { localStorage.setItem('userServer', serverId); } catch(e) {}
}

function onUserServerChange() {
    const sel = document.getElementById('user-server-select');
    if (!sel) return;
    saveUserServer(parseInt(sel.value) || 2);
    updateHeaderRate();
    updateUserServerHint();
}

function updateUserServerHint() {
    const hint = document.getElementById('user-server-hint');
    if (!hint) return;
    const info = getServerInfo(userServer);
    if (!info) { hint.textContent = '—'; return; }
    if (info.id === 0) {
        hint.textContent = `1 VC$ = 1 VC$ (Vice City)`;
    } else {
        hint.textContent = `1 VC$ = ${info.sell_rate} SA$ · ${info.name}`;
    }
}

function buildUserServerSelect() {
    const sel = document.getElementById('user-server-select');
    if (!sel) return;
    sel.innerHTML = '';
    currencyRates.forEach(s => {
        const opt = document.createElement('option');
        opt.value = s.id;
        opt.textContent = s.id === 0 ? `0. ${s.name}` : `${s.id}. ${s.name}`;
        if (s.id === userServer) opt.selected = true;
        sel.appendChild(opt);
    });
    updateUserServerHint();
}

// ─── Currency rates init ─────────────────────────────────────
async function loadCurrencyRates() {
    try {
        const res  = await fetch('/api/currency_rates');
        const data = await res.json();
        if (data.success) {
            currencyRates = data.rates;
            buildServerSelects();
            buildUserServerSelect();
            updateHeaderRate();
        }
    } catch(e) {}
}

function buildServerSelects() {
    const buyEl  = document.getElementById('buy-server-select');
    const sellEl = document.getElementById('sell-server-select');
    if (!buyEl || !sellEl) return;
    buyEl.innerHTML  = '';
    sellEl.innerHTML = '';
    currencyRates.forEach(s => {
        const label = s.id === 0 ? `0. ${s.name}` : `${s.id}. ${s.name}`;

        const optBuy = document.createElement('option');
        optBuy.value = s.id;
        optBuy.textContent = label;
        if (s.id === selectedBuyServer) optBuy.selected = true;
        buyEl.appendChild(optBuy);

        const optSell = document.createElement('option');
        optSell.value = s.id;
        optSell.textContent = label;
        if (s.id === selectedSellServer) optSell.selected = true;
        sellEl.appendChild(optSell);
    });
}

function getServerInfo(serverId) {
    return currencyRates.find(s => s.id === serverId) || null;
}

function updateHeaderRate() {
    const info    = getServerInfo(userServer);
    const rateEl  = document.getElementById('header-rate-value');
    const nameEl  = document.getElementById('user-server-name');
    if (!rateEl) return;
    if (info) {
        if (nameEl) nameEl.textContent = info.id === 0 ? 'Vice City' : info.name;
        rateEl.textContent = info.id === 0
            ? `1 VC$ = 1 VC$`
            : `1 VC$ = ${info.sell_rate} SA$`;
    } else {
        if (nameEl) nameEl.textContent = 'Сервер';
        rateEl.textContent = '1 VC$ = — SA$';
    }
}

function onServerChange() {
    const buyEl  = document.getElementById('buy-server-select');
    const sellEl = document.getElementById('sell-server-select');
    selectedBuyServer  = parseInt(buyEl.value)  || 0;
    selectedSellServer = parseInt(sellEl.value) || 2;
    updateArbSubtitle();
    loadArbitrage();
}

function updateArbSubtitle() {
    const buyInfo  = getServerInfo(selectedBuyServer);
    const sellInfo = getServerInfo(selectedSellServer);
    if (!buyInfo || !sellInfo) return;
    const rateStr = sellInfo.id === 0
        ? '1 VC$ = 1 VC$'
        : `1 VC$ = ${sellInfo.sell_rate} SA$`;
    document.getElementById('page-subtitle').textContent =
        `${buyInfo.name} → ${sellInfo.name} · ${rateStr}`;
}

// ─── Logout ──────────────────────────────────────────────────
function handleLogout() {
    if (confirm('Выйти из личного кабинета?')) {
        window.location.href = '/logout';
    }
}

// ─── Arbitrage Filters ───────────────────────────────────────
function loadArbFilters() {
    try {
        const saved = localStorage.getItem('arbFilters');
        if (saved) arbFilters = JSON.parse(saved);
    } catch(e) {}
    const profitInp = document.getElementById('filter-min-profit');
    if (profitInp) profitInp.value = arbFilters.minProfit > 0 ? arbFilters.minProfit : '';
    const lavkasInp = document.getElementById('filter-min-lavkas');
    if (lavkasInp) lavkasInp.value = arbFilters.minLavkas > 0 ? arbFilters.minLavkas : '';
    renderExcludedTags();
    updateFilterBadge();
}

function saveArbFilters() {
    localStorage.setItem('arbFilters', JSON.stringify(arbFilters));
    updateFilterBadge();
}

function onFilterChange() {
    arbFilters.minProfit = parseInt(document.getElementById('filter-min-profit').value) || 0;
    arbFilters.minLavkas = parseInt(document.getElementById('filter-min-lavkas').value) || 0;
    saveArbFilters();
    if (lastArbitrageData) {
        const filtered = applyArbFilters(lastArbitrageData);
        const buyInfo  = getServerInfo(selectedBuyServer);
        const sellInfo = getServerInfo(selectedSellServer);
        updateArbitrageContent(lastArbitrageData, '✅', null,
            selectedBuyServer, selectedSellServer,
            buyInfo?.name, sellInfo?.name, sellInfo?.sell_rate);
    }
}

function toggleFilterPanel() {
    const panel = document.getElementById('arb-filter-panel');
    const btn   = document.getElementById('arb-filter-btn');
    panel.classList.toggle('open');
    btn.classList.toggle('active', panel.classList.contains('open'));
}

function addExcludedItem() {
    const input = document.getElementById('filter-exclude-input');
    const val   = input.value.trim();
    if (!val) return;
    if (!arbFilters.excludedItems.some(i => i.toLowerCase() === val.toLowerCase())) {
        arbFilters.excludedItems.push(val);
        saveArbFilters();
        renderExcludedTags();
        if (lastArbitrageData) {
            const buyInfo  = getServerInfo(selectedBuyServer);
            const sellInfo = getServerInfo(selectedSellServer);
            updateArbitrageContent(lastArbitrageData, '✅', null,
                selectedBuyServer, selectedSellServer,
                buyInfo?.name, sellInfo?.name, sellInfo?.sell_rate);
        }
    }
    input.value = '';
    input.focus();
}

function removeExcludedItem(index) {
    arbFilters.excludedItems.splice(index, 1);
    saveArbFilters();
    renderExcludedTags();
    if (lastArbitrageData) {
        const buyInfo  = getServerInfo(selectedBuyServer);
        const sellInfo = getServerInfo(selectedSellServer);
        updateArbitrageContent(lastArbitrageData, '✅', null,
            selectedBuyServer, selectedSellServer,
            buyInfo?.name, sellInfo?.name, sellInfo?.sell_rate);
    }
}

function renderExcludedTags() {
    const container = document.getElementById('excluded-tags');
    if (!container) return;
    if (!arbFilters.excludedItems.length) { container.innerHTML = ''; return; }
    container.innerHTML = arbFilters.excludedItems.map((item, i) =>
        `<span class="exclude-tag">${item}<button class="tag-remove" onclick="removeExcludedItem(${i})">×</button></span>`
    ).join('');
}

function updateFilterBadge() {
    const badge = document.getElementById('filter-badge');
    if (!badge) return;
    const count = (arbFilters.minProfit > 0 ? 1 : 0) + (arbFilters.minLavkas > 0 ? 1 : 0) + arbFilters.excludedItems.length;
    if (count > 0) { badge.textContent = count; badge.style.display = 'inline-flex'; }
    else badge.style.display = 'none';
}

function applyArbFilters(deals) {
    let filtered = deals;
    if (arbFilters.minProfit > 0) filtered = filtered.filter(d => d.total_profit >= arbFilters.minProfit);
    if (arbFilters.minLavkas > 0) filtered = filtered.filter(d => (d.sell_lavka_count || 0) >= arbFilters.minLavkas);
    if (arbFilters.excludedItems.length > 0) {
        filtered = filtered.filter(d =>
            !arbFilters.excludedItems.some(ex => d.item.toLowerCase().includes(ex.toLowerCase()))
        );
    }
    return filtered;
}

// ─── Background canvas ───────────────────────────────────────
function initCanvas() {
    const canvas = document.getElementById('bg-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    function resize() { canvas.width = window.innerWidth; canvas.height = window.innerHeight; }
    resize();
    window.addEventListener('resize', resize);
    const dots   = [];
    const COUNT  = 50;
    const colors = ['53,0,211', '56,189,248', '34,197,94'];
    for (let i = 0; i < COUNT; i++) {
        dots.push({
            x: Math.random() * canvas.width, y: Math.random() * canvas.height,
            r: Math.random() * 1.2 + 0.3,
            vx: (Math.random() - 0.5) * 0.10, vy: (Math.random() - 0.5) * 0.10,
            o: Math.random() * 0.3 + 0.08,
            c: colors[Math.floor(Math.random() * colors.length)]
        });
    }
    function draw() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        dots.forEach(d => {
            d.x += d.vx; d.y += d.vy;
            if (d.x < 0 || d.x > canvas.width) d.vx *= -1;
            if (d.y < 0 || d.y > canvas.height) d.vy *= -1;
            ctx.beginPath(); ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(${d.c},${d.o})`; ctx.fill();
        });
        for (let i = 0; i < dots.length; i++) {
            for (let j = i + 1; j < dots.length; j++) {
                const dx = dots[i].x - dots[j].x, dy = dots[i].y - dots[j].y;
                const dist = Math.sqrt(dx*dx + dy*dy);
                if (dist < 100) {
                    ctx.beginPath();
                    ctx.moveTo(dots[i].x, dots[i].y);
                    ctx.lineTo(dots[j].x, dots[j].y);
                    ctx.strokeStyle = `rgba(91,95,239,${0.08 * (1 - dist/100)})`;
                    ctx.lineWidth = 0.4; ctx.stroke();
                }
            }
        }
        requestAnimationFrame(draw);
    }
    draw();
}

// ─── Best Deals ──────────────────────────────────────────────
let lastBdData = null;

async function loadBestDeals() {
    try {
        const res  = await fetch('/api/best_deals');
        const data = await res.json();
        lastBdData = data;
        renderBestDeals(data);
    } catch(e) {}
}

async function scanBestDeals() {
    const btn = document.getElementById('bd-scan-btn');
    btn.disabled = true;
    btn.textContent = 'Сканирую...';
    const bdStatus = document.getElementById('bd-status');
    if (bdStatus) bdStatus.querySelector('span:last-child').textContent = 'Сканирую все серверы...';
    document.getElementById('bd-content').innerHTML =
        '<div class="empty-state"><div class="spinner"></div><p>Сканирую все 33 сервера...</p></div>';
    await fetch('/scan_best_deals', {method: 'POST'});
    setTimeout(async () => {
        await loadBestDeals();
        btn.disabled = false;
        btn.innerHTML = `<svg width="15" height="15" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="7" stroke="currentColor" stroke-width="1.5"/><path d="M10 6v4l3 2" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg> Скан`;
    }, 4000);
}

function applyBdFilters() {
    if (lastBdData) renderBestDeals(lastBdData);
}

function renderBestDeals(data) {
    const content   = document.getElementById('bd-content');
    const statusEl  = document.getElementById('bd-status');
    const minProfit = parseFloat(document.getElementById('bd-min-profit')?.value) || 0;
    const minPct    = parseFloat(document.getElementById('bd-min-pct')?.value)    || 0;

    if (statusEl) statusEl.querySelector('span:last-child').textContent =
        data.status + (data.last_update ? ' · ' + data.last_update : '');

    let deals = data.deals || [];
    if (minProfit > 0) deals = deals.filter(d => d.total_profit_vc >= minProfit);
    if (minPct    > 0) deals = deals.filter(d => d.profit_pct     >= minPct);

    if (!deals.length) {
        content.innerHTML = `<div class="empty-state"><p>${!data.deals?.length ? 'Нажмите «Скан», чтобы начать сканирование' : 'Нет сделок по заданным фильтрам'}</p></div>`;
        return;
    }

    const totalProfitVc = deals.reduce((s, d) => s + d.total_profit_vc, 0);

    let html = `
        <div class="stats-card">
            <div class="stat-item"><span class="stat-label">Сделок</span><span class="stat-value">${deals.length}</span></div>
            <div class="stat-item"><span class="stat-label">Общий профит</span><span class="stat-value green">+${Math.ceil(totalProfitVc).toLocaleString()} VC$</span></div>
        </div>
    `;

    const buyGroups = {};
    deals.forEach(d => {
        if (!buyGroups[d.lavka_buy]) buyGroups[d.lavka_buy] = [];
        buyGroups[d.lavka_buy].push(d);
    });

    const sortedLavkas = Object.keys(buyGroups)
        .map(id => ({ id, profit: buyGroups[id].reduce((s, d) => s + d.total_profit_vc, 0) }))
        .sort((a, b) => b.profit - a.profit)
        .map(x => x.id);

    sortedLavkas.forEach(buyLavka => {
        const group       = [...buyGroups[buyLavka]].sort((a, b) => b.total_profit_vc - a.total_profit_vc);
        const groupProfit = group.reduce((s, d) => s + d.total_profit_vc, 0);
        const buySrvName  = currencyRates.find(s => s.id === group[0].buy_server)?.name || `Сервер ${group[0].buy_server}`;

        html += `
            <div class="arb-card">
                <div class="arb-head">
                    <div class="arb-icon">💹</div>
                    <span class="arb-id">Лавка #${buyLavka}
                        <span style="color:var(--text-muted);font-weight:400;font-size:12px;">${buySrvName}</span>
                    </span>
                    <span class="arb-count">${group.length} сделок</span>
                    <span class="arb-total">+${Math.ceil(groupProfit).toLocaleString()} VC$</span>
                </div>
                <div class="table-wrap">
                    <table class="arb-table">
                        <thead><tr>
                            <th>Скуп Лавка</th><th>Сервер</th><th>Предмет</th>
                            <th>Покупка</th><th>Скупка</th>
                            <th>Профит/шт</th><th>%</th><th>Итого (VC$)</th><th>Кол-во</th><th></th>
                        </tr></thead>
                        <tbody>
        `;
        group.slice(0, 20).forEach(d => {
            const bc          = d.buy_currency  || 'SA$';
            const sc          = d.sell_currency || 'SA$';
            const sellSrvName = currencyRates.find(s => s.id === d.sell_server)?.name || `Сервер ${d.sell_server}`;
            html += `
                <tr>
                    <td class="td-sell">#${d.lavka_sell}</td>
                    <td class="td-num" style="font-size:11px">${sellSrvName}</td>
                    <td class="td-item td-clickable" title="${d.item}" onclick="copyItemName('${d.item.replace(/'/g, "\\'")}')">${d.item.slice(0, 26)}${d.item.length > 26 ? '…' : ''}</td>
                    <td class="td-num">${Math.ceil(d.price_buy).toLocaleString()} ${bc}</td>
                    <td class="td-num">${Math.ceil(d.price_sell).toLocaleString()} ${sc}</td>
                    <td class="td-profit">+${Math.ceil(d.profit_vc).toLocaleString()} VC$</td>
                    <td class="td-pct">+${d.profit_pct}%</td>
                    <td class="td-profit">+${Math.ceil(d.total_profit_vc).toLocaleString()} VC$</td>
                    <td class="td-num">${d.count_buy}</td>
                    <td class="td-action"><button class="btn-copy-small" onclick="copyToClipboard('/findilavka ${d.lavka_sell}')">копировать</button></td>
                </tr>
            `;
        });
        html += `</tbody></table>`;
        if (group.length > 20) html += `<div class="more-deals">+${group.length - 20} ещё сделок</div>`;
        html += `</div></div>`;
    });

    content.innerHTML = html;
}

// ─── Tab switching ───────────────────────────────────────────
function switchTab(tabName) {
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    document.querySelectorAll('.bnav-item').forEach(n => n.classList.remove('active'));

    document.getElementById(tabName)?.classList.add('active');
    const sideNav = document.getElementById('nav-' + tabName);
    if (sideNav) sideNav.classList.add('active');
    const botNav = document.getElementById('bnav-' + tabName);
    if (botNav) botNav.classList.add('active');

    const titles = {
        scanner:   ['Продажа через лавки',            'inventory.json · сервер 0'],
        dashboard: ['Дашборд',                         'Статистика баланса'],
        market:    ['Рынок',                           'Поиск товаров по лавкам'],
        bestdeals: ['Лучшие сделки',                   'Глобальный арбитраж по всем серверам'],
        settings:  ['Настройки',                       'Профиль и параметры'],
    };

    if (tabName === 'arbitrage') {
        document.getElementById('page-title').textContent = 'Арбитраж';
        updateArbSubtitle();
        loadArbitrage();
    } else if (titles[tabName]) {
        document.getElementById('page-title').textContent    = titles[tabName][0];
        document.getElementById('page-subtitle').textContent = titles[tabName][1];
        if (tabName === 'scanner')   loadScanner();
        else if (tabName === 'dashboard') loadDashboard();
        else if (tabName === 'market') setTimeout(() => document.getElementById('market-search-input')?.focus(), 50);
        else if (tabName === 'bestdeals') loadBestDeals();
    }
}

// ─── Inventory Modal ─────────────────────────────────────────
async function showInventoryModal() {
    const modal   = document.getElementById('inventoryModal');
    const content = document.getElementById('inventoryContent');
    content.innerHTML = '<div class="empty-state"><div class="spinner"></div><p>Загрузка инвентаря...</p></div>';
    modal.classList.add('open');
    try {
        const res  = await fetch('/api/inventory-summary?t=' + Date.now());
        const data = await res.json();
        if (data.success && data.data.items.length > 0) {
            const d = data.data;
            let html = `
                <div class="inv-summary">
                    <div class="inv-sum-item"><span class="inv-sum-label">Видов</span><span class="inv-sum-value">${d.item_types}</span></div>
                    <div class="inv-sum-item"><span class="inv-sum-label">Штук</span><span class="inv-sum-value">${d.total_items.toLocaleString()}</span></div>
                    <div class="inv-sum-item"><span class="inv-sum-label">Стоимость</span><span class="inv-sum-value gold">${d.total_cost.toLocaleString()}</span></div>
                </div>
            `;
            d.items.forEach(item => {
                html += `
                    <div class="inv-item">
                        <div>
                            <div class="inv-name">${item.name}</div>
                            <div class="inv-qty">${item.qty.toLocaleString()} шт</div>
                        </div>
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <span class="inv-cost">${item.total_cost.toLocaleString()} SA$</span>
                            <button class="btn-delete-item" onclick="deleteItem('${item.name.replace(/'/g, "\\'")}')">
                                <svg width="14" height="14" viewBox="0 0 20 20" fill="none">
                                    <path d="M3 5h14M8 5V3h4v2M8 9v6M12 9v6M5 5h10l-1 13H6L5 5Z" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                `;
            });
            content.innerHTML = html;
        } else {
            content.innerHTML = '<div class="empty-state"><p>Инвентарь пуст</p></div>';
        }
        updateHeaderStats();
    } catch(e) {
        content.innerHTML = '<div class="empty-state"><p>Ошибка загрузки</p></div>';
    }
}

function closeInventoryModal() { document.getElementById('inventoryModal').classList.remove('open'); }

// ─── Scanner ─────────────────────────────────────────────────
async function loadScanner() {
    try {
        const res  = await fetch('/api/scanner');
        const resp = await res.json();
        updateScannerContent(resp);
    } catch(e) {}
}

async function scanScanner() {
    if (scannerLoading) return;
    scannerLoading = true;
    document.getElementById('scanner-content').innerHTML =
        '<div class="empty-state"><div class="spinner"></div><p>Сканирую лавки...</p></div>';
    await fetch('/scan_scanner', {method: 'POST'});
    setTimeout(() => { loadScanner(); scannerLoading = false; }, 2500);
}

async function toggleAutoScanner() {
    const res    = await fetch('/toggle_auto_scanner', {method: 'POST'});
    const result = await res.json();
    const btn    = document.getElementById('auto-scanner-btn');
    const dot    = document.getElementById('dot-scanner');
    if (result.scanner_running) {
        btn.classList.add('active');
        btn.querySelector('.toggle-label').textContent = 'Автоскан: ВКЛ';
        dot.classList.add('on');
        setStatus('scanner-status', 'ok', 'Автоскан активен — обновление каждые 30 сек');
    } else {
        btn.classList.remove('active');
        btn.querySelector('.toggle-label').textContent = 'Автоскан';
        dot.classList.remove('on');
        setStatus('scanner-status', '', 'Автоскан выключен');
    }
}

// ─── Arbitrage BUY→SELL ──────────────────────────────────────
async function loadArbitrage() {
    try {
        const res  = await fetch(`/api/arbitrage?buy=${selectedBuyServer}&sell=${selectedSellServer}`);
        const resp = await res.json();
        // resp.data = {deals: [...], status: "...", last_update: "..."}
        const state = resp.data || {};
        updateArbitrageContent(state.deals || [], state.status, state.last_update,
                               resp.buy_id, resp.sell_id, resp.buy_name, resp.sell_name, resp.sell_rate);
    } catch(e) {}
}

async function scanArbitrage() {
    if (arbitrageLoading) return;
    arbitrageLoading = true;
    const btn = document.getElementById('arbitrage-scan-btn');
    btn.disabled = true;
    btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="7" stroke="currentColor" stroke-width="1.5"/></svg> Сканирую...';
    const buyInfo  = getServerInfo(selectedBuyServer);
    const sellInfo = getServerInfo(selectedSellServer);
    setStatus('arbitrage-status', '', `Сканирую ${buyInfo?.name || selectedBuyServer} → ${sellInfo?.name || selectedSellServer}...`);
    await fetch(`/scan_arbitrage?buy=${selectedBuyServer}&sell=${selectedSellServer}`, {method: 'POST'});
    setTimeout(() => {
        loadArbitrage();
        btn.disabled = false;
        btn.innerHTML = '<svg width="15" height="15" viewBox="0 0 20 20" fill="none"><path d="M3 10h14M13 6l4 4-4 4M7 6L3 10l4 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg> Скан';
        arbitrageLoading = false;
    }, 3000);
}

async function toggleAutoArbitrage() {
    const res    = await fetch('/toggle_auto_arbitrage', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ buy: selectedBuyServer, sell: selectedSellServer })
    });
    const result = await res.json();
    const btn    = document.getElementById('auto-arbitrage-btn');
    const dot    = document.getElementById('dot-arbitrage');
    if (result.arbitrage_running) {
        btn.classList.add('active');
        btn.querySelector('.toggle-label').textContent = 'Автоарби: ВКЛ';
        dot.classList.add('on');
    } else {
        btn.classList.remove('active');
        btn.querySelector('.toggle-label').textContent = 'Автоарби';
        dot.classList.remove('on');
    }
}

// ─── Status bar helper ───────────────────────────────────────
function setStatus(id, type, text) {
    const bar = document.getElementById(id);
    if (!bar) return;
    const ind = bar.querySelector('.status-indicator');
    if (ind) ind.className = 'status-indicator' + (type ? ' ' + type : '');
    const span = bar.querySelector('span');
    if (span) span.textContent = text;
}

// ─── Scanner Content ─────────────────────────────────────────
// resp = full API response: {success, data: [sorted_lavki, total_stats]}
// sorted_lavki = [[lavka_uid, {item_name: [item_objs]}], ...]
// item_obj = {name, quantity, buy_price, buy_price_per_unit, lavka_uid, lavka_price, lavka_count, profit, entries}
function updateScannerContent(resp) {
    const content  = document.getElementById('scanner-content');
    const statusEl = document.getElementById('scanner-status');

    if (!resp || !resp.success || !resp.data) {
        setStatus('scanner-status', '', 'Нет данных — нажмите «Скан» для запуска');
        content.innerHTML = '<div class="empty-state"><p>Нажмите «Скан» для запуска сканирования</p></div>';
        return;
    }

    // data is [sorted_lavki, total_stats]
    const sortedLavki = resp.data[0] || [];   // [[uid, {name: [items]}], ...]
    const totalStats  = resp.data[1] || {};

    if (!sortedLavki.length) {
        setStatus('scanner-status', '', 'Нет предметов в inventory.json');
        content.innerHTML = '<div class="empty-state"><p>Нет предметов в инвентаре</p></div>';
        return;
    }

    const totalProfit = totalStats.total_profit || 0;
    const totalItems  = totalStats.item_groups  || 0;
    const lavkaCount  = totalStats.lavka_count  || 0;
    setStatus('scanner-status', 'ok', `${lavkaCount} лавок · ${totalItems} позиций · профит +${Math.ceil(totalProfit).toLocaleString()} SA$`);

    let html = `
        <div class="stats-card">
            <div class="stat-item"><span class="stat-label">Лавок</span><span class="stat-value">${lavkaCount}</span></div>
            <div class="stat-item"><span class="stat-label">Позиций</span><span class="stat-value">${totalItems}</span></div>
            <div class="stat-item"><span class="stat-label">Профит</span><span class="stat-value green">+${Math.ceil(totalProfit).toLocaleString()} SA$</span></div>
        </div>
    `;

    sortedLavki.forEach(([lavkaUid, itemGroups]) => {
        // itemGroups = {item_name: [item_objs]}
        const allItems = Object.values(itemGroups).flat();
        const lavkaProfit = allItems.reduce((s, it) => s + (it.profit || 0), 0);
        const posClass    = lavkaProfit >= 0 ? 'pos' : 'neg';
        const sign        = lavkaProfit >= 0 ? '+' : '';

        html += `
            <div class="lavka-card">
                <div class="lavka-head">
                    <div class="lavka-icon">🏪</div>
                    <span class="lavka-id">Лавка #${lavkaUid}</span>
                    <span class="lavka-items-count">${allItems.length} позиций</span>
                    <button class="copy-cmd-btn" onclick="copyToClipboard('/findilavka ${lavkaUid}')">
                        📋 /findilavka ${lavkaUid}
                    </button>
                    <span class="lavka-profit ${posClass}">${sign}${Math.ceil(lavkaProfit).toLocaleString()} SA$</span>
                </div>
                <div class="lavka-body">
        `;

        allItems.sort((a, b) => (b.profit || 0) - (a.profit || 0));
        allItems.forEach(item => {
            const profit  = item.profit || 0;
            const pClass  = profit >= 0 ? 'profit-ok' : 'profit-bad';
            const profCls = profit >= 0 ? 'pos' : 'neg';
            const pSign   = profit >= 0 ? '+' : '';
            html += `
                <div class="detail-line ${pClass}">
                    <div class="detail-line-left">
                        <span class="detail-name">${item.name}</span>
                        <span class="detail-buy">Куплено: ${(item.buy_price_per_unit || 0).toLocaleString()} SA$/шт × ${item.quantity || 0} шт</span>
                    </div>
                    <div class="detail-line-right">
                        <span class="detail-lavka">Скупка: ${(item.lavka_price || 0).toLocaleString()} VC$ · ${item.lavka_count || 0} шт</span>
                        <span class="detail-profit ${profCls}">${pSign}${Math.ceil(profit).toLocaleString()} SA$</span>
                    </div>
                </div>
            `;
        });

        html += `</div></div>`;
    });

    content.innerHTML = html;
}

// ─── Arbitrage Content ───────────────────────────────────────
// deals = array of deal objects from data.data.deals
function updateArbitrageContent(deals, apiStatus, lastUpdate, buyId, sellId, buyName, sellName, sellRate) {
    const content = document.getElementById('arbitrage-content');

    // Save deals for filter re-apply
    lastArbitrageData = deals;

    const statusText = apiStatus || '';
    const hasScanned = statusText !== 'Нажмите «Скан»' && statusText !== '';

    if (!hasScanned) {
        setStatus('arbitrage-status', '', 'Нажмите «Скан» для запуска арбитража');
        content.innerHTML = '<div class="empty-state"><p>Нажмите «Скан» для запуска арбитража</p></div>';
        return;
    }

    const filtered = applyArbFilters(deals || []);

    const rateStr = sellId === 0 ? '1 VC$=1 VC$' : `1 VC$ = ${sellRate} SA$`;
    const label   = buyName && sellName
        ? `${buyName} → ${sellName} · ${rateStr} · ${filtered.length} сделок`
        : statusText;
    setStatus('arbitrage-status', filtered.length > 0 ? 'ok' : '', label);

    if (!filtered.length) {
        content.innerHTML = `<div class="empty-state"><p>${hasScanned ? 'Нет арбитражных возможностей по выбранным параметрам' : 'Нажмите «Скан» для запуска арбитража'}</p></div>`;
        return;
    }

    // Group by buy lavka
    const grouped = {};
    filtered.forEach(d => {
        const key = d.lavka_buy || '?';
        if (!grouped[key]) grouped[key] = [];
        grouped[key].push(d);
    });

    const sortedLavkas = Object.keys(grouped)
        .map(id => ({ id, profit: grouped[id].reduce((s, d) => s + (d.total_profit || 0), 0) }))
        .sort((a, b) => b.profit - a.profit)
        .map(x => x.id);

    let html = '';
    sortedLavkas.forEach(lavkaId => {
        const group       = [...grouped[lavkaId]].sort((a, b) => (b.total_profit || 0) - (a.total_profit || 0));
        const groupProfit = group.reduce((s, d) => s + (d.total_profit || 0), 0);
        const currency    = sellId === 0 ? 'VC$' : 'SA$';

        html += `
            <div class="arb-card">
                <div class="arb-head">
                    <div class="arb-icon">🔄</div>
                    <span class="arb-id">Лавка #${lavkaId}</span>
                    <span class="arb-count">${group.length} позиций</span>
                    <button class="copy-cmd-btn" onclick="copyToClipboard('/findilavka ${lavkaId}')">📋 /findilavka ${lavkaId}</button>
                    <span class="arb-total">+${Math.ceil(groupProfit).toLocaleString()} ${currency}</span>
                </div>
                <div class="table-wrap">
                    <table class="arb-table">
                        <thead><tr>
                            <th>Скуп лавка</th><th>Предмет</th><th>Покупка</th>
                            <th>Скупка</th><th>Профит/шт</th><th>%</th><th>Итого</th><th>Кол-во</th><th></th>
                        </tr></thead>
                        <tbody>
        `;
        group.slice(0, 30).forEach(d => {
            const buyCur  = d.buy_currency  || (buyId  === 0 ? 'VC$' : 'SA$');
            const sellCur = d.sell_currency || (sellId === 0 ? 'VC$' : 'SA$');
            html += `
                <tr>
                    <td class="td-sell">#${d.lavka_sell || '—'}</td>
                    <td class="td-item" title="${d.item}">${(d.item || '—').slice(0, 26)}${(d.item || '').length > 26 ? '…' : ''}</td>
                    <td class="td-num">${Math.ceil(d.price_buy || 0).toLocaleString()} ${buyCur}</td>
                    <td class="td-num">${Math.ceil(d.price_sell || 0).toLocaleString()} ${sellCur}</td>
                    <td class="td-profit">+${Math.ceil(d.profit || 0).toLocaleString()} ${sellCur}</td>
                    <td class="td-pct">${d.profit_pct || 0}%</td>
                    <td class="td-profit">+${Math.ceil(d.total_profit || 0).toLocaleString()} ${sellCur}</td>
                    <td class="td-num">${d.count_buy || 0} шт</td>
                    <td class="td-action"><button class="btn-copy-small" onclick="copyToClipboard('/findilavka ${d.lavka_sell}')">копировать</button></td>
                </tr>
            `;
        });
        html += `</tbody></table>`;
        if (group.length > 30) html += `<div class="more-deals">+${group.length - 30} ещё позиций</div>`;
        html += `</div></div>`;
    });

    content.innerHTML = html;
}

// ─── Dashboard ───────────────────────────────────────────────
let balanceChart = null;

async function loadDashboard() {
    try {
        const res  = await fetch('/api/balance/history');
        const data = await res.json();
        if (!data.success) return;
        renderDashboard(data.records || []);
    } catch(e) {}
}

function renderDashboard(records) {
    const todayEl   = document.getElementById('dash-today');
    const allEl     = document.getElementById('dash-all');
    const curEl     = document.getElementById('dash-current');
    const countEl   = document.getElementById('dash-count');
    const histEl    = document.getElementById('dash-history-list');
    const chartSub  = document.getElementById('dash-chart-sub');

    if (!records.length) {
        if (todayEl)  todayEl.textContent  = '0 SA$';
        if (allEl)    allEl.textContent    = '0 SA$';
        if (curEl)    curEl.textContent    = '— SA$';
        if (countEl)  countEl.textContent  = '0';
        if (histEl)   histEl.innerHTML     = '<div class="empty-state" style="min-height:120px"><p>Нет записей. Добавьте первый баланс.</p></div>';
        return;
    }

    const today     = new Date().toDateString();
    const todayRecs = records.filter(r => new Date(r.timestamp).toDateString() === today);
    const todayProfit = todayRecs.length > 1
        ? todayRecs[todayRecs.length-1].amount - todayRecs[0].amount
        : 0;
    const allProfit = records.length > 1
        ? records[records.length-1].amount - records[0].amount
        : 0;

    if (todayEl) todayEl.textContent  = (todayProfit >= 0 ? '+' : '') + Math.round(todayProfit).toLocaleString() + ' SA$';
    if (allEl)   allEl.textContent    = (allProfit   >= 0 ? '+' : '') + Math.round(allProfit).toLocaleString()   + ' SA$';
    if (curEl)   curEl.textContent    = Math.round(records[records.length-1].amount).toLocaleString() + ' SA$';
    if (countEl) countEl.textContent  = records.length;
    if (chartSub) chartSub.textContent = `SA$ · ${records.length} записей`;

    const sorted = [...records].sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
    if (histEl) {
        histEl.innerHTML = [...sorted].reverse().map((r, i, arr) => {
            const prev  = arr[i + 1];
            const delta = prev ? r.amount - prev.amount : null;
            const dSign = delta !== null ? (delta >= 0 ? '+' : '') : '';
            const dCls  = delta !== null ? (delta >= 0 ? 'pos' : 'neg') : '';
            const dt    = new Date(r.timestamp);
            const timeStr = dt.toLocaleString('ru', { day:'2-digit', month:'2-digit', hour:'2-digit', minute:'2-digit' });
            return `
                <div class="hist-row">
                    <div class="hist-left">
                        <span class="hist-time">${timeStr}</span>
                        <span class="hist-note">${r.note || '—'}</span>
                    </div>
                    <div class="hist-right">
                        <span class="hist-amount">${Math.round(r.amount).toLocaleString()} SA$</span>
                        ${delta !== null ? `<span class="hist-delta ${dCls}">${dSign}${Math.round(delta).toLocaleString()}</span>` : ''}
                        <button class="btn-copy-small" onclick="deleteBalanceRecord('${r.id}')">✕</button>
                    </div>
                </div>
            `;
        }).join('');
    }

    const labels = sorted.map(r => {
        const dt = new Date(r.timestamp);
        return dt.toLocaleString('ru', { day:'2-digit', month:'2-digit', hour:'2-digit', minute:'2-digit' });
    });
    const values = sorted.map(r => r.amount);

    const ctx = document.getElementById('balance-chart')?.getContext('2d');
    if (!ctx) return;
    if (balanceChart) { balanceChart.destroy(); balanceChart = null; }

    balanceChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels,
            datasets: [{
                data: values,
                borderColor: '#5B5FEF',
                backgroundColor: 'rgba(91,95,239,0.12)',
                borderWidth: 2,
                pointRadius: values.length > 30 ? 0 : 3,
                pointHoverRadius: 5,
                fill: true,
                tension: 0.35,
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false }, tooltip: {
                backgroundColor: '#1A1D27',
                borderColor: 'rgba(91,95,239,0.45)',
                borderWidth: 1,
                titleColor: '#fafaf8',
                bodyColor: '#c4b5fd',
                callbacks: { label: ctx => ' ' + Math.round(ctx.parsed.y).toLocaleString() + ' SA$' }
            }},
            scales: {
                x: { display: false },
                y: {
                    grid: { color: 'rgba(255,255,255,0.05)' },
                    ticks: { color: '#52525b', font: { family: 'JetBrains Mono', size: 11 }, callback: v => v.toLocaleString() }
                }
            }
        }
    });
}

async function addBalanceRecord() {
    const amountEl = document.getElementById('balance-amount-input');
    const noteEl   = document.getElementById('balance-note-input');
    const amount   = parseFloat(amountEl.value);
    if (!amount || amount < 0) return;
    try {
        await fetch('/api/balance/add', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ amount, note: noteEl.value.trim() })
        });
        amountEl.value = '';
        noteEl.value   = '';
        loadDashboard();
    } catch(e) {}
}

async function deleteBalanceRecord(id) {
    try {
        await fetch('/api/balance/delete', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ id })
        });
        loadDashboard();
    } catch(e) {}
}

// ─── Market ──────────────────────────────────────────────────
let marketData    = null;
let marketSortAsc = true;

function buildMarketServerSelect() {
    const sel = document.getElementById('market-server-select');
    if (!sel) return;
    sel.innerHTML = '';
    currencyRates.forEach(s => {
        const opt = document.createElement('option');
        opt.value = s.id;
        opt.textContent = s.id === 0 ? `0. ${s.name}` : `${s.id}. ${s.name}`;
        if (s.id === userServer) opt.selected = true;
        sel.appendChild(opt);
    });
}

async function searchMarket() {
    const query    = document.getElementById('market-search-input').value.trim();
    const serverId = parseInt(document.getElementById('market-server-select').value) || 0;
    const btn      = document.getElementById('market-search-btn');

    if (!query) {
        setStatus('market-status', '', 'Введите название товара');
        return;
    }
    btn.disabled = true;
    btn.innerHTML = '<svg width="15" height="15" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="7" stroke="currentColor" stroke-width="1.5"/></svg> Ищу...';
    setStatus('market-status', '', `Поиск "${query}" на сервере ${serverId}...`);
    try {
        const res  = await fetch(`/api/market?q=${encodeURIComponent(query)}&server=${serverId}`);
        const data = await res.json();
        if (!data.success) {
            setStatus('market-status', '', data.error || 'Ошибка поиска');
        } else {
            marketData = data;
            const totalBuy  = data.buy_shops.length;
            const totalSell = data.sell_shops.length;
            if (totalBuy + totalSell === 0) {
                setStatus('market-status', '', `Ничего не найдено по запросу "${query}"`);
            } else {
                setStatus('market-status', 'ok', `Найдено: ${totalBuy} скупщиков · ${totalSell} продавцов`);
            }
            renderMarket();
        }
    } catch(e) {
        setStatus('market-status', '', 'Ошибка соединения');
    } finally {
        btn.disabled = false;
        btn.innerHTML = '<svg width="15" height="15" viewBox="0 0 20 20" fill="none"><circle cx="8.5" cy="8.5" r="5.5" stroke="currentColor" stroke-width="1.5"/><path d="M13 13l3 3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg> Поиск';
    }
}

function toggleMarketSort() {
    marketSortAsc = !marketSortAsc;
    const label = document.getElementById('market-sort-label');
    const btn   = document.getElementById('market-sort-btn');
    if (marketSortAsc) { label.textContent = 'По цене ↑'; btn.classList.remove('sort-desc'); }
    else               { label.textContent = 'По цене ↓'; btn.classList.add('sort-desc'); }
    renderMarket();
}

function renderMarket() {
    const buyList  = document.getElementById('market-buy-list');
    const sellList = document.getElementById('market-sell-list');
    const buyCount  = document.getElementById('buy-count');
    const sellCount = document.getElementById('sell-count');
    const sortFn = (a, b) => marketSortAsc ? a.price - b.price : b.price - a.price;
    const buySorted  = [...(marketData.buy_shops  || [])].sort(sortFn);
    const sellSorted = [...(marketData.sell_shops || [])].sort(sortFn);
    if (buyCount)  buyCount.textContent  = buySorted.length  ? `(${buySorted.length})`  : '';
    if (sellCount) sellCount.textContent = sellSorted.length ? `(${sellSorted.length})` : '';
    buyList.innerHTML  = buySorted.length  ? renderMarketRows(buySorted,  'buy')  : '<div class="empty-state" style="min-height:200px"><p>Скупщики не найдены</p></div>';
    sellList.innerHTML = sellSorted.length ? renderMarketRows(sellSorted, 'sell') : '<div class="empty-state" style="min-height:200px"><p>Продавцы не найдены</p></div>';
}

function renderMarketRows(shops, type) {
    const serverId = parseInt(document.getElementById('market-server-select').value) || 0;
    const currency = serverId === 0 ? 'VC$' : 'SA$';
    let html = `
        <table class="market-table">
            <thead><tr>
                <th>Лавка</th>
                <th>Товар</th>
                <th>${type === 'buy' ? `Цена скупки (${currency})` : `Цена продажи (${currency})`}</th>
                <th>Кол-во</th>
                <th></th>
            </tr></thead>
            <tbody>
    `;
    shops.forEach(s => {
        html += `
            <tr>
                <td class="td-lavka">#${s.lavka_uid}</td>
                <td class="td-item" title="${s.item_name}">${s.item_name.slice(0, 28)}${s.item_name.length > 28 ? '…' : ''}</td>
                <td class="td-price ${type === 'buy' ? 'price-buy' : 'price-sell'}">${s.price.toLocaleString()} ${currency}</td>
                <td class="td-count">${s.count > 0 ? s.count.toLocaleString() + ' шт' : '—'}</td>
                <td class="td-action">
                    <button class="btn-copy-small" onclick="copyToClipboard('/findilavka ${s.lavka_uid}')">копировать</button>
                </td>
            </tr>
        `;
    });
    html += '</tbody></table>';
    return html;
}

// ─── Item modals ─────────────────────────────────────────────
let selectedItemName = '';

async function openAddItemModal() {
    closeInventoryModal();
    document.getElementById('addItemModal').classList.add('open');
    document.getElementById('itemSearchInput').focus();
}

function closeAddItemModal() {
    document.getElementById('addItemModal').classList.remove('open');
}

async function searchItems() {
    const query   = document.getElementById('itemSearchInput').value.trim();
    const results = document.getElementById('itemSearchResults');
    if (!query || query.length < 2) {
        results.innerHTML = '<p style="color:var(--text-secondary);text-align:center;padding:20px">Начните печатать для поиска...</p>';
        return;
    }
    try {
        const res  = await fetch(`/api/search-items?q=${encodeURIComponent(query)}`);
        const data = await res.json();
        if (!data.success || !data.items.length) {
            results.innerHTML = '<p style="color:var(--text-muted);text-align:center;padding:20px">Ничего не найдено</p>';
            return;
        }
        results.innerHTML = data.items.slice(0, 30).map(item => `
            <div class="inv-item" style="cursor:pointer;margin-bottom:6px" onclick="openItemDetails('${item.name.replace(/'/g,"\\'")}')">
                <div>
                    <div class="inv-name">${item.name}</div>
                    <div class="inv-qty" style="margin-top:2px">${item.category || ''}</div>
                </div>
                <svg width="16" height="16" viewBox="0 0 20 20" fill="none"><path d="M5 10h10M10 5l5 5-5 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </div>
        `).join('');
    } catch(e) {
        results.innerHTML = '<p style="color:var(--text-muted);text-align:center;padding:20px">Ошибка загрузки</p>';
    }
}

function openItemDetails(itemName) {
    selectedItemName = itemName;
    document.getElementById('itemDetailsName').textContent = itemName;
    document.getElementById('itemQtyInput').value   = '';
    document.getElementById('itemPriceInput').value = '';
    document.getElementById('addItemModal').classList.remove('open');
    document.getElementById('itemDetailsModal').classList.add('open');
    setTimeout(() => document.getElementById('itemQtyInput').focus(), 50);
}

function closeItemDetailsModal() {
    document.getElementById('itemDetailsModal').classList.remove('open');
}

async function confirmAddItem() {
    const qty   = parseInt(document.getElementById('itemQtyInput').value);
    const price = parseFloat(document.getElementById('itemPriceInput').value);
    if (!qty || !price || qty < 1 || price < 0) return;
    try {
        const res  = await fetch('/api/add-item', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ name: selectedItemName, qty, price_per_unit: price })
        });
        const data = await res.json();
        if (data.success) {
            closeItemDetailsModal();
            showToast('Предмет добавлен в инвентарь');
        }
    } catch(e) {}
}

async function deleteItem(itemName) {
    if (!confirm(`Удалить «${itemName}» из инвентаря?`)) return;
    try {
        await fetch('/api/delete-item', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ name: itemName })
        });
        showInventoryModal();
    } catch(e) {}
}

// ─── Copy helpers ─────────────────────────────────────────────
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => showToast('Скопировано в буфер')).catch(() => {});
}

function copyItemName(name) {
    copyToClipboard(name);
}

function showToast(msg) {
    const toast = document.getElementById('copy-toast');
    if (!toast) return;
    toast.textContent = msg;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 2200);
}

// ─── Init ────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
    initLoader();
    initCanvas();
    loadUserServer();

    await loadCurrencyRates();
    buildMarketServerSelect();

    document.getElementById('inventoryModal').addEventListener('click', function(e) {
        if (e.target === this) closeInventoryModal();
    });
    document.getElementById('addItemModal').addEventListener('click', function(e) {
        if (e.target === this) closeAddItemModal();
    });
    document.getElementById('itemDetailsModal').addEventListener('click', function(e) {
        if (e.target === this) closeItemDetailsModal();
    });

    async function pollStatus() {
        try {
            const res    = await fetch('/api/auto_status');
            const status = await res.json();

            const scanBtn = document.getElementById('auto-scanner-btn');
            const scanDot = document.getElementById('dot-scanner');
            if (status.scanner_running) {
                scanBtn.classList.add('active');
                scanBtn.querySelector('.toggle-label').textContent = 'Автоскан: ВКЛ';
                scanDot.classList.add('on');
            }

            const arbBtn = document.getElementById('auto-arbitrage-btn');
            const arbDot = document.getElementById('dot-arbitrage');
            if (status.arbitrage_running) {
                arbBtn.classList.add('active');
                arbBtn.querySelector('.toggle-label').textContent = 'Автоарби: ВКЛ';
                arbDot.classList.add('on');
            }
        } catch(e) {}
    }

    setInterval(pollStatus, 5000);

    setInterval(() => {
        if (document.getElementById('scanner').classList.contains('active')) loadScanner();
    }, 30000);

    setInterval(() => {
        const arbBtn = document.getElementById('auto-arbitrage-btn');
        if (arbBtn.classList.contains('active') && document.getElementById('arbitrage').classList.contains('active')) {
            loadArbitrage();
        }
    }, 10000);

    document.getElementById('auto-scanner-btn').onclick   = toggleAutoScanner;
    document.getElementById('auto-arbitrage-btn').onclick = toggleAutoArbitrage;

    loadArbFilters();
    loadScanner();

    const balanceInput = document.getElementById('balance-amount-input');
    if (balanceInput) balanceInput.addEventListener('keydown', e => { if (e.key === 'Enter') addBalanceRecord(); });
    const noteInput = document.getElementById('balance-note-input');
    if (noteInput) noteInput.addEventListener('keydown', e => { if (e.key === 'Enter') addBalanceRecord(); });

    const itemSearchInput = document.getElementById('itemSearchInput');
    if (itemSearchInput) itemSearchInput.addEventListener('input', searchItems);
});
